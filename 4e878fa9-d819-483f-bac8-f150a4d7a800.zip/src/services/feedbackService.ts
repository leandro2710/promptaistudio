import { collection, addDoc } from "firebase/firestore";
import { db } from "@/src/lib/firebase";

export async function submitSuggestion(content: string, user: any) {
  try {
    await addDoc(collection(db, 'suggestions'), {
      uid: user.uid,
      userId: user.uid,
      userName: user.name || 'Anônimo',
      userEmail: user.email || 'Não informado',
      userPhoto: user.photoURL || '',
      content: content.trim(),
      type: 'prompt',
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    });
  } catch (error) {
    console.error("Error submitting suggestion:", error);
    throw error;
  }
}

export async function submitReport(description: string, user: any) {
  try {
    await addDoc(collection(db, 'reports'), {
      uid: user.uid,
      userId: user.uid,
      userName: user.name || 'Anônimo',
      userEmail: user.email || 'Não informado',
      userPhoto: user.photoURL || '',
      description: description.trim(),
      problemType: 'other',
      status: 'open',
      priority: 'medium',
      createdAt: new Date(),
      updatedAt: new Date()
    });
  } catch (error) {
    console.error("Error submitting report:", error);
    throw error;
  }
}
