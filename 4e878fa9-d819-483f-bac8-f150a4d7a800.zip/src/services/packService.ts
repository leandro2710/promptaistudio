import { collection, query, where, orderBy, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { Pack } from '@/src/types';

const PACKS_COLLECTION = 'packs';

export const getActivePacks = async (): Promise<Pack[]> => {
  try {
    const q = query(collection(db, PACKS_COLLECTION), where('active', '==', true));
    const snapshot = await getDocs(q);
    const packs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pack));
    return packs.sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
       try {
         const qFree = query(collection(db, PACKS_COLLECTION), where('active', '==', true), where('access', '==', 'free'));
         const snap = await getDocs(qFree);
         const packs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pack));
         return packs.sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));
       } catch (e: any) {
         console.warn("⚠️ Aviso: Fallback de packs negado. Você publicou o firestore.rules no Firebase?");
       }
    } else {
       console.warn("⚠️ Aviso: Erro ao buscar packs:", error?.message);
    }
    return [];
  }
};

export const getFeaturedPacks = async (): Promise<Pack[]> => {
  try {
    const q = query(collection(db, PACKS_COLLECTION), where('active', '==', true), where('featured', '==', true));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pack));
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
       try {
         const qFree = query(collection(db, PACKS_COLLECTION), where('active', '==', true), where('access', '==', 'free'), where('featured', '==', true));
         const snap = await getDocs(qFree);
         return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pack));
       } catch (e: any) {
         console.warn("⚠️ Aviso: Fallback de packs em destaque negado. Você publicou o firestore.rules no Firebase?");
       }
    } else if (error?.code === 'failed-precondition') {
       try {
         const qFree = query(collection(db, PACKS_COLLECTION), where('active', '==', true));
         const snap = await getDocs(qFree);
         return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pack)).filter((p) => p.featured);
       } catch (e) {
           console.warn("⚠️ Aviso: Index missing packs", e);
       }
    } else {
       console.warn("⚠️ Aviso: Erro ao buscar packs em destaque:", error?.message);
    }
    return [];
  }
};

export const getPackById = async (id: string): Promise<Pack | null> => {
  try {
    const docRef = doc(db, PACKS_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Pack;
    }
    return null;
  } catch (error) {
    console.error("Error fetching pack:", error);
    return null;
  }
};
