import { collection, query, where, orderBy, getDocs, limit, doc, getDoc, documentId } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { Prompt } from '@/src/types';

const PROMPTS_COLLECTION = 'prompts';

export const getActivePrompts = async (filters: { platform?: string; category?: string; type?: string; level?: string; access?: string } = {}): Promise<Prompt[]> => {
  try {
    let q = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true));
    
    if (filters.access) {
      q = query(q, where('access', '==', filters.access));
    }
    
    q = query(q, limit(50));
    const snapshot = await getDocs(q);
    return filterAndSortPrompts(snapshot.docs, filters);
  } catch (error: any) {
    if (error?.code === 'permission-denied' && !filters.access) {
      try {
        let qFree = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true), where('access', '==', 'free'), limit(50));
        const snapFree = await getDocs(qFree);
        return filterAndSortPrompts(snapFree.docs, filters);
      } catch (e2: any) {
        console.warn("⚠️ Aviso: Permissão negada ao acessar prompts via fallback (free). Você publicou o firestore.rules no Firebase?");
        throw new Error("Permissão negada. As regras do Firestore não permitem a leitura.");
      }
    }
    console.warn(`⚠️ Aviso: Permissão negada ao acessar prompts. Publique o firestore.rules no Firebase. Detalhe: ${error.message}`);
    throw new Error("Erro ao buscar prompts. O Firestore bloqueou a leitura.");
  }
};

const filterAndSortPrompts = (docs: any[], filters: any): Prompt[] => {
  let prompts = docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
  
  if (filters.platform) {
    prompts = prompts.filter(p => p.platform === filters.platform || p.platforms?.includes(filters.platform!));
  }
  if (filters.category) {
    prompts = prompts.filter(p => p.category === filters.category || p.categories?.includes(filters.category!));
  }
  if (filters.type) {
    prompts = prompts.filter(p => p.type === filters.type);
  }
  if (filters.level) {
     prompts = prompts.filter(p => p.level === filters.level);
  }
  
  return prompts.sort((a,b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));
};

export const getFeaturedPrompts = async (maxLimit: number = 10): Promise<Prompt[]> => {
  try {
    const q = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true), where('featured', '==', true), limit(maxLimit));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
       try {
         const qFree = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true), where('access', '==', 'free'), where('featured', '==', true), limit(maxLimit));
         const snap = await getDocs(qFree);
         return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
       } catch (e: any) {
           console.warn("⚠️ Aviso: Fallback de prompts em destaque negado. Verifique as regras do Firestore.");
       }
    } else if (error?.code === 'failed-precondition') {
       // Typically missing index
       try {
         // Fallback without featured filter to avoid index if needed, but then we must filter locally
         const qFree = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true), limit(50));
         const snap = await getDocs(qFree);
         return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt)).filter(p => p.featured).slice(0, maxLimit);
       } catch (e) {
           console.warn("⚠️ Aviso: Index missing", e);
       }
    } else {
       console.warn("⚠️ Aviso: Erro ao buscar prompts em destaque:", error?.message);
    }
    return [];
  }
};

export const getRecentPrompts = async (maxLimit: number = 10): Promise<Prompt[]> => {
  try {
    const q = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true));
    const snapshot = await getDocs(q);
    const prompts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
    return prompts.sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0)).slice(0, maxLimit);
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
       try {
         const qFree = query(collection(db, PROMPTS_COLLECTION), where('active', '==', true), where('access', '==', 'free'));
         const snap = await getDocs(qFree);
         const prompts = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
         return prompts.sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0)).slice(0, maxLimit);
       } catch (e: any) {
           console.warn("⚠️ Aviso: Fallback de prompts recentes negado. Verifique as regras do Firestore.");
       }
    } else {
       console.warn("⚠️ Aviso: Erro ao buscar prompts recentes:", error?.message);
    }
    return [];
  }
};

export const getPromptById = async (id: string): Promise<Prompt | null> => {
  // Use session cache first maybe? We'll rely on React state cache or simple local cache
  try {
    const docRef = doc(db, PROMPTS_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Prompt;
    }
    return null;
  } catch (error) {
    console.error("Error fetching prompt:", error);
    return null;
  }
};

export const searchPromptsLocally = (prompts: Prompt[], queryStr: string): Prompt[] => {
  if (!queryStr) return prompts;
  const q = queryStr.toLowerCase();
  return prompts.filter(p => 
    p.title.toLowerCase().includes(q) || 
    p.description.toLowerCase().includes(q) ||
    p.tags?.some(tag => tag.toLowerCase().includes(q))
  );
};

export const getPromptsByCategory = async (categorySlug: string): Promise<Prompt[]> => {
  return await getActivePrompts({ category: categorySlug });
};

export const getPromptsByIds = async (ids: string[]): Promise<Prompt[]> => {
  if (!ids || ids.length === 0) return [];
  try {
    const q = query(collection(db, PROMPTS_COLLECTION), where(documentId(), 'in', ids.slice(0, 10)), where('active', '==', true));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Prompt));
  } catch (error) {
    console.error("Error fetching prompts by IDs:", error);
    return [];
  }
};
