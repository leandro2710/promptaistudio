import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { Update } from '@/src/types';

const UPDATES_COLLECTION = 'updates';

export const getActiveUpdates = async (): Promise<Update[]> => {
  try {
    const q = query(collection(db, UPDATES_COLLECTION), where('active', '==', true));
    const snapshot = await getDocs(q);
    const updates = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Update));
    
    // Sort pinned first locally to avoid complex composite indexes
    const sorted = updates.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      // If displayOrder is set, use it
      if (a.displayOrder !== undefined && b.displayOrder !== undefined) return a.displayOrder - b.displayOrder;
      return (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0); // Sort by createdAt desc locally
    });

    return sorted;
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
        console.warn("⚠️ Aviso: Permissão negada ao buscar updates. As regras do Firestore (firestore.rules) foram publicadas no Firebase?");
    } else {
        console.warn("⚠️ Aviso: Erro ao buscar updates:", error?.message);
    }
    return [];
  }
};

