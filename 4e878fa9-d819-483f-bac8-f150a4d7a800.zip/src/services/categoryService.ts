import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { Category } from '@/src/types';

const CATEGORIES_COLLECTION = 'categories';

export const getActiveCategories = async (): Promise<Category[]> => {
  try {
    const q = query(collection(db, CATEGORIES_COLLECTION), where('active', '==', true));
    const snapshot = await getDocs(q);
    const categories = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category));
    categories.sort((a, b) => (a.order || 0) - (b.order || 0));
    return categories;
  } catch (error: any) {
    if (error?.code === 'permission-denied') {
       console.warn("⚠️ Aviso: Não foi possível ler as categorias. As regras do Firestore (firestore.rules) estão devidamente publicadas no seu Firebase?");
    } else {
       console.warn("⚠️ Aviso: Erro ao ler categorias:", error?.message);
    }
    return [];
  }
};

export const getCategoriesByType = async (type: string): Promise<Category[]> => {
  const all = await getActiveCategories();
  return all.filter(c => c.type === type);
};

export const getCategoryBySlug = async (slug: string): Promise<Category | null> => {
  const all = await getActiveCategories();
  return all.find(c => c.slug === slug) || null;
};
