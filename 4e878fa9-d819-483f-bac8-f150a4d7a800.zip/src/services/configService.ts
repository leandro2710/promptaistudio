import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { AppConfig } from '@/src/types';

const FALLBACK_CONFIG: AppConfig = {
  ecosystemId: 'promptai_ecosystem_v1',
  publicAppName: 'PromptAI Studio',
  adminAppName: 'PromptAI Admin',
  publicAppPackage: 'com.promptai.studio',
  adminAppPackage: 'com.promptai.admin',
  plusPrice: 'R$ 29,90',
  whatsappNumber: '5512988986713',
  whatsappMessage: 'Olá! Quero assinar o PromptAI Studio Plus e acessar os packs plus de prompts.',
  maintenanceMode: false,
  minVersion: '1.0.0',
  latestVersion: '1.0.0'
};

export const getConfig = async (): Promise<AppConfig | null> => {
  try {
    const docRef = doc(db, 'appConfig', 'main');
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return docSnap.data() as AppConfig;
    }
    return null;
  } catch (error: any) {
    console.warn("⚠️ Aviso: Erro ao buscar config (Pode ser permissão do Firestore). Retornando ao fallback. Detalhe:", error?.message);
    return null;
  }
};

export const getConfigWithFallback = async (): Promise<AppConfig> => {
  const config = await getConfig();
  if (config) return config;
  
  return FALLBACK_CONFIG;
};
