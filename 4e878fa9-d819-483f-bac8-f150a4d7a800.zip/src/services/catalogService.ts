import { getFeaturedPrompts } from "@/src/services/promptService";
import { getFeaturedPacks } from "@/src/services/packService";
import { Prompt, Pack } from "@/src/types";

export async function getCombinedFeaturedContent(): Promise<(Prompt | Pack)[]> {
  const [featPrompts, featPacks] = await Promise.all([
    getFeaturedPrompts(10),
    getFeaturedPacks()
  ]);
  
  // Merge featured prompts and packs
  const combined = [...featPrompts, ...featPacks];
  
  // Sort by Pinned then Featured then Date
  combined.sort((a, b) => {
     if (a.pinned && !b.pinned) return -1;
     if (!a.pinned && b.pinned) return 1;
     if (a.displayOrder !== undefined && b.displayOrder !== undefined) return (a.displayOrder - b.displayOrder);
     return (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0);
  });

  return combined;
}
