import { doc, getDoc, setDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { User as FirebaseUser } from 'firebase/auth';
import { User, Role, Status } from '@/src/types';

export const getCurrentUserDoc = async (uid: string): Promise<User | null> => {
  try {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, uid: docSnap.id, ...docSnap.data() } as User;
    }
    return null;
  } catch (error) {
    console.error("Error getting user doc:", error);
    return null;
  }
};

export const createOrUpdateUserOnLogin = async (firebaseUser: FirebaseUser): Promise<User | null> => {
  if (!firebaseUser) return null;
  
  try {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      // Update only safe fields, preserve isPlus, plusUntil, role, status
      await setDoc(userRef, {
        name: firebaseUser.displayName || 'Usuário',
        email: firebaseUser.email || '',
        photoURL: firebaseUser.photoURL || '',
        lastLoginAt: serverTimestamp()
      }, { merge: true });
      
      return { id: userSnap.id, uid: userSnap.id, ...userSnap.data(), name: firebaseUser.displayName || 'Usuário', photoURL: firebaseUser.photoURL || '' } as User;
    } else {
      // Create new user
      const newUser: Omit<User, 'id'> = {
        uid: firebaseUser.uid,
        name: firebaseUser.displayName || 'Usuário',
        email: firebaseUser.email || '',
        photoURL: firebaseUser.photoURL || '',
        isPlus: false,
        plusUntil: null,
        createdAt: serverTimestamp() as Timestamp,
        lastLoginAt: serverTimestamp() as Timestamp,
        role: 'user',
        status: 'active'
      };
      
      await setDoc(userRef, newUser);
      return { id: firebaseUser.uid, ...newUser } as User;
    }
  } catch (error) {
    console.error("Error creating/updating user:", error);
    return null;
  }
};
