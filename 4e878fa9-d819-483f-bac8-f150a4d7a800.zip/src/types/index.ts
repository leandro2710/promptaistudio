import type { Timestamp } from "firebase/firestore";

export interface Prompt {
  id?: string;
  title: string;
  slug: string;
  description: string;
  platform: string;
  platforms: string[];
  category: string;
  categories: string[];
  type: string;
  access: "free" | "plus";
  level: "basico" | "intermediario" | "avancado" | "profissional";
  content: string;
  editableFields: string[];
  usageInstructions: string;
  expectedResult: string;
  exampleOutput: string;
  videoExampleURL?: string;
  audioExampleURL?: string;
  tested: boolean;
  testedAt: Timestamp | null;
  testedOn: string[];
  tags: string[];
  coverURL: string;
  thumbnailURL?: string;
  imageURL?: string;
  active: boolean;
  featured: boolean;
  pinned?: boolean;
  displayOrder?: number;
  copyCount: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  createdBy: string;
  suggestedBy?: {
    name: string;
    photoURL?: string;
    uid?: string;
  };
}

export interface Category {
  id?: string;
  name: string;
  slug: string;
  type: "platform" | "content" | "level" | "special";
  icon: string;
  color: string;
  order: number;
  active: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Pack {
  id?: string;
  title: string;
  slug: string;
  description: string;
  access: "free" | "plus";
  category: string;
  promptIds: string[];
  benefits: string[];
  coverURL: string;
  thumbnailURL?: string;
  imageURL?: string;
  active: boolean;
  featured: boolean;
  pinned?: boolean;
  displayOrder?: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  suggestedBy?: {
    name: string;
    photoURL?: string;
    uid?: string;
  };
}

export interface Update {
  id?: string;
  title: string;
  message: string;
  version?: string;
  type: "news" | "warning" | "feature" | "maintenance" | "update" | "prompt" | "pack";
  downloadURL?: string;
  thumbnailURL?: string;
  targetId?: string;
  targetCollection?: "prompts" | "packs" | "updates" | "external";
  active: boolean;
  pinned?: boolean;
  displayOrder?: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type Role = "user" | "plus" | "admin";
export type Status = "active" | "blocked";

export interface User {
  id?: string;
  uid: string;
  name: string;
  email: string;
  photoURL: string;
  tag?: string;      // Optional tags like @username
  userTag?: string;
  isPlus: boolean;
  plusUntil: Timestamp | null;
  createdAt: Timestamp;
  lastLoginAt: Timestamp;
  role: Role;
  status: Status;
}

export interface AppConfig {
  id?: string;
  ecosystemId: "promptai_ecosystem_v1" | string;
  publicAppName: string;
  adminAppName: string;
  publicAppPackage: string;
  adminAppPackage: string;
  plusPrice: string;
  whatsappNumber: string;
  whatsappMessage: string;
  maintenanceMode: boolean;
  minVersion: string;
  latestVersion: string;
  supportEmail?: string;
}

export interface Suggestion {
  id?: string;
  uid: string;
  userName: string;
  userEmail: string;
  title: string;
  message: string;
  platform: string;
  category: string;
  status: "new" | "reviewing" | "accepted" | "rejected";
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Report {
  id?: string;
  uid: string;
  userName: string;
  userEmail: string;
  title: string;
  message: string;
  area: string;
  priority: "low" | "medium" | "high";
  status: "new" | "reviewing" | "resolved";
  createdAt: Timestamp;
  updatedAt: Timestamp;
}


