import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Category } from "@/src/types";
import { getActiveCategories } from "@/src/services/categoryService";
import { CategoryCard } from "@/src/components/category/CategoryCard";

export function Categories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const res = await getActiveCategories();
      setCategories(res);
      setLoading(false);
    };
    load();
  }, []);

  const groupBy = (array: Category[], key: keyof Category) => {
    return array.reduce((result: Record<string, Category[]>, currentValue) => {
      const groupKey = currentValue[key] as string;
      (result[groupKey] = result[groupKey] || []).push(currentValue);
      return result;
    }, {});
  };

  const grouped = groupBy(categories, 'type');

  return (
    <div className="space-y-6 pb-8">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight">Categorias</h1>
        <p className="text-sm text-zinc-400">Navegue pelos prompts por plataformas ou conteúdos.</p>
      </div>

      {loading ? (
        <div className="grid gap-4">
          {Array.from({length: 4}).map((_, i) => <div key={i} className="animate-pulse h-20 bg-white/5 rounded-3xl" />)}
        </div>
      ) : categories.length > 0 ? (
        <div className="space-y-8">
          {Object.entries(grouped).map(([type, cats]) => (
            <div key={type} className="space-y-3">
              <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-widest pl-2">
                 {type === 'platform' ? 'Plataformas' : type === 'content' ? 'Conteúdo' : type === 'level' ? 'Níveis' : 'Especiais'}
              </h2>
              <div className="grid gap-3">
                {cats.map(cat => (
                  <CategoryCard key={cat.id} category={cat} />
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center text-zinc-500 text-sm">
          Nenhuma categoria ativa encontrada.
        </div>
      )}
    </div>
  );
}
