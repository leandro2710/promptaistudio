import { useEffect, useState } from "react";
import { AppConfig } from "@/src/types";
import { getConfigWithFallback } from "@/src/services/configService";
import { GlassCard } from "@/src/components/ui/GlassCard";
import { Sparkles, Code2, Database, ShieldCheck, Mail, Share2, Star, LifeBuoy, ChevronRight } from "lucide-react";
import { useAuth } from "@/src/hooks/useAuth";
import { usePlus } from "@/src/hooks/usePlus";
import { Badge } from "@/src/components/ui/Badge";
import toast from "react-hot-toast";

import { PromptAILogo } from "@/src/components/brand/PromptAILogo";

export function About() {
  const [config, setConfig] = useState<AppConfig | null>(null);
  const { user } = useAuth();
  const { isPlus, userRole } = usePlus();

  useEffect(() => {
    getConfigWithFallback().then(setConfig);
  }, []);

  const handleShare = () => {
    const url = window.location.origin;
    if (navigator.share) {
      navigator.share({ title: 'PromptAI Studio', url }).catch(console.error);
    } else {
      navigator.clipboard.writeText(url);
      toast.success("Link do aplicativo copiado!");
    }
  };

  const ActionRow = ({ icon: Icon, title, onClick }: any) => (
    <button 
      onClick={onClick}
      className={`w-full flex items-center justify-between p-4 bg-card hover:bg-card-hover transition-colors first:rounded-t-[20px] last:rounded-b-[20px] border-b border-white/5 text-zinc-200`}
    >
      <div className="flex items-center gap-3">
        <Icon className="h-5 w-5 text-zinc-400" />
        <span className="font-medium text-[15px]">{title}</span>
      </div>
      <ChevronRight className="h-4 w-4 text-zinc-500" />
    </button>
  );

  return (
    <div className="space-y-6 pb-8">
      <div className="text-center py-10 flex flex-col items-center">
         <PromptAILogo size={72} variant="glow" className="mb-6 logo-strong-glow" />
         <h1 className="text-3xl font-bold tracking-tight mb-2 text-white">{config?.publicAppName || 'PromptAI Studio'}</h1>
         <p className="text-zinc-400 text-sm max-w-[250px]">A sua biblioteca definitiva de prompts organizados e testados.</p>
      </div>

      <GlassCard className="p-6">
         <div className="flex justify-between items-center">
            <h3 className="font-semibold text-white">Versão do Aplicativo</h3>
            <Badge variant="secondary" className="bg-white/5">{config?.latestVersion || '1.0.0'}</Badge>
         </div>
      </GlassCard>

      <GlassCard className="p-6 space-y-5">
         <h3 className="font-semibold text-white mb-2">Sobre o aplicativo</h3>
         <p className="text-zinc-300 text-sm leading-relaxed">
           O <strong>PromptAI Studio</strong> foi desenvolvido para impulsionar a sua criatividade e otimizar processos na criação de conteúdo com Inteligência Artificial.
         </p>
         <p className="text-zinc-400 text-sm leading-relaxed">
           Ideal para criadores de conteúdo, copywriters, designers e profissionais que buscam os melhores prompts e templates para plataformas como ChatGPT, Claude, Gemini, e geradores de imagem como Midjourney e Leonardo AI.
         </p>
         
         {config?.supportEmail && (
           <div className="flex items-start gap-3 pt-5 border-t border-white/5 mt-4">
              <div className="p-2 bg-white/5 rounded-xl mt-0.5">
                <Mail className="h-4 w-4 text-zinc-400" />
              </div>
              <div>
                 <p className="text-sm font-medium text-zinc-200">Contato de Suporte</p>
                 <p className="text-xs text-zinc-500">{config.supportEmail}</p>
              </div>
           </div>
         )}
      </GlassCard>
    </div>
  );
}
