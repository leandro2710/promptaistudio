import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Sparkles, Pin, Zap, Star, Bell, Newspaper } from "lucide-react";
import toast from "react-hot-toast";
import { Prompt, Pack, AppConfig, Update } from "@/src/types";
import { useAuth } from "@/src/hooks/useAuth";
import { getActiveUpdates } from "@/src/services/updateService";
import { getCombinedFeaturedContent } from "@/src/services/catalogService";
import { getConfigWithFallback } from "@/src/services/configService";
import { PromptCard } from "@/src/components/prompt/PromptCard";
import { PackCard } from "@/src/components/pack/PackCard";
import { BaseCard } from "@/src/components/ui/BaseCard";
import { PlusCTA } from "@/src/components/plus/PlusCTA";
import { Button } from "@/src/components/ui/Button";
import { Badge } from "@/src/components/ui/Badge";
import { cn } from "@/src/lib/utils";
import { useQuery } from "@tanstack/react-query";

export function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: config } = useQuery({
    queryKey: ['config'],
    queryFn: getConfigWithFallback,
    staleTime: 1000 * 60 * 60 // 1 hour
  });

  const { data: featuredContent = [], isLoading: loadingContent, error: contentError } = useQuery({
    queryKey: ['featuredContent'],
    queryFn: getCombinedFeaturedContent
  });

  const { data: updates = [], isLoading: loadingUpdates } = useQuery({
    queryKey: ['updates'],
    queryFn: async () => {
      const upds = await getActiveUpdates();
      return upds.slice(0, 3);
    }
  });

  const loading = loadingContent || loadingUpdates;

  useEffect(() => {
    if (contentError) {
       toast.error("Erro ao carregar conteúdo destacado", { id: 'error-load' });
    }
  }, [contentError]);

  if (config?.maintenanceMode) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center px-4">
        <Sparkles className="h-12 w-12 text-zinc-600 mb-6 opacity-30" />
        <h2 className="text-2xl font-display font-bold text-zinc-300 mb-2">Estamos ajustando os bastidores.</h2>
        <h2 className="text-xl font-display font-bold text-zinc-300 mb-4">Volta logo — vai valer a pena ⚙️</h2>
        <p className="opacity-60 text-sm text-zinc-400">Agradecemos sua paciência enquanto preparamos o novo ambiente.</p>
      </div>
    );
  }

  const handleUpdateClick = (update: Update) => {
    if (update.targetId && update.targetCollection) {
      if (update.targetCollection === "prompts") navigate(`/prompt/${update.targetId}`);
      else if (update.targetCollection === "packs") navigate(`/pack/${update.targetId}`);
    } else if (update.downloadURL) {
      window.open(update.downloadURL, "_blank");
    } else {
      navigate('/updates');
    }
  };

  return (
    <div className="space-y-6 pb-8">

      {/* Plus CTA (Only for Free) */}
      {(!user?.isPlus) && (
        <PlusCTA price={config?.plusPrice} className="!py-4" />
      )}

      {/* Novidades */}
      {updates.length > 0 && (
         <section>
           <div className="flex flex-col mb-4">
             <div className="flex items-center justify-between">
               <div className="flex items-center gap-2">
                 <Newspaper className="h-5 w-5 text-primary drop-shadow-[0_0_8px_rgba(var(--color-primary),0.5)] fill-primary/20" />
                 <h2 className="text-lg font-bold tracking-tight">Novidades</h2>
               </div>
               <Link to="/updates" className="text-xs text-primary-light font-medium hover:text-white transition-colors">
                 Ver todas
               </Link>
             </div>
           </div>
           
           <div className="grid gap-3">
             {loading ? (
               Array.from({length: 3}).map((_, i) => <div key={i} className="animate-pulse h-20 bg-white/5 rounded-2xl" />)
             ) : (
               updates.map(update => (
                 <div 
                   key={update.id} 
                   onClick={() => handleUpdateClick(update)}
                   className="flex items-center gap-4 bg-card border border-white/5 p-3 rounded-2xl cursor-pointer hover:bg-card-hover hover:border-primary/20 transition-all group"
                 >
                   {update.thumbnailURL ? (
                     <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-white/5">
                       <img src={update.thumbnailURL} alt={update.title} className="w-full h-full object-cover" />
                     </div>
                   ) : (
                     <div className="flex items-center justify-center shrink-0 w-14 h-14 rounded-xl bg-primary/10 border border-primary/20">
                        <Newspaper className="h-6 w-6 text-primary" />
                      </div>
                   )}
                   <div className="flex-1 min-w-0">
                     <div className="flex items-center gap-2 mb-1">
                       <h3 className="text-sm font-semibold truncate group-hover:text-primary-light transition-colors">{update.title}</h3>
                       {update.pinned && <Pin className="h-3 w-3 text-primary-light shrink-0" />}
                     </div>
                     <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">{update.message}</p>
                   </div>
                 </div>
               ))
             )}
           </div>
         </section>
      )}

      {/* Conteúdos em Destaque */}
      <section>
        <div className="flex items-center justify-between mb-4 mt-2">
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-primary drop-shadow-[0_0_8px_rgba(var(--color-primary),0.5)] fill-primary/20" />
            <h2 className="text-lg font-bold tracking-tight">Conteúdos em destaque</h2>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {loading ? (
            Array.from({length: 4}).map((_, i) => <BaseCard.Skeleton key={i} className={i % 4 === 0 ? "md:col-span-2" : ""} />)
          ) : featuredContent.length > 0 ? (
            featuredContent.map((item, i) => {
              const bentoClass = i % 4 === 0 ? "md:col-span-2" : "";
              if ('editableFields' in item) {
                return (
                  <div key={`prompt-${item.id}`} className={bentoClass}>
                    <PromptCard prompt={item as Prompt} />
                  </div>
                );
              } else {
                return (
                  <div key={`pack-${item.id}`} className={bentoClass}>
                    <PackCard pack={item as Pack} />
                  </div>
                );
              }
            })
          ) : (
            <div className="px-6 py-12 text-center bg-card rounded-3xl border border-white/5 flex flex-col items-center justify-center">
              <Sparkles className="h-10 w-10 mb-4 text-zinc-600 opacity-50" />
              <h3 className="font-display font-bold text-lg text-zinc-300 mb-2">Nada em destaque ainda. Os melhores prompts estão a caminho 🎨</h3>
              <p className="opacity-60 text-sm text-zinc-400">
                Explore os <Link to="/packs" className="underline hover:text-white">packs disponíveis</Link>.
              </p>
            </div>
          )}
        </div>
      </section>

    </div>
  );
}
