import { useNavigate } from "react-router-dom";
import { Check } from "lucide-react";
import { signInWithPopup, googleProvider, auth } from "@/src/lib/firebase";
import { createOrUpdateUserOnLogin } from "@/src/services/userService";
import { Button } from "@/src/components/ui/Button";
import toast from "react-hot-toast";
import { useAuth } from "@/src/hooks/useAuth";
import { PromptAILogo } from "@/src/components/brand/PromptAILogo";
import { useEffect } from "react";

const GoogleIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

export function Login() {
  const navigate = useNavigate();
  const { user, refreshUser } = useAuth();

  useEffect(() => {
    if (user) {
      navigate("/home");
    }
  }, [user, navigate]);

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await createOrUpdateUserOnLogin(result.user);
      await refreshUser();
      toast.success("Login com sucesso!");
      navigate("/home");
    } catch (error: any) {
      console.error(error);
      if (error.code === "auth/unauthorized-domain") {
          toast.error("Domínio não autorizado. Adicione a URL base deste app no menu Authentication > Settings > Authorized domains do Firebase.", { duration: 8000 });
      } else if (error.code !== "auth/popup-closed-by-user") {
          toast.error("Erro ao fazer login: " + (error.message || ""));
      }
    }
  };

  return (
    <div className="flex flex-col min-h-[100dvh] bg-background pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,var(--logo-surface-from,rgba(124,58,237,0.15)),transparent_60%)] pointer-events-none" />
      <div className="flex-1 flex flex-col justify-center px-6 max-w-sm mx-auto w-full py-12 relative z-10">
        
        <div className="bg-card/40 backdrop-blur-xl border border-white/10 p-8 rounded-[32px] shadow-2xl relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
          <div className="relative z-10 w-full flex flex-col items-center">
            
            <div className="mx-auto mb-8 flex h-28 w-28 items-center justify-center drop-shadow-[0_0_45px_var(--logo-glow,rgba(124,58,237,0.22))]">
              <PromptAILogo size={96} variant="glow" />
            </div>
            
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold tracking-tight mb-2">PromptAI Studio</h1>
              <p className="text-sm text-zinc-400">Entre para acessar o conteúdo especial.</p>
            </div>

            <Button onClick={handleGoogleLogin} size="lg" className="w-full bg-white text-black hover:bg-zinc-200 shadow-md">
              <GoogleIcon className="mr-2 h-5 w-5" /> Entrar com Google
            </Button>
          </div>
        </div>

        <div className="mt-12 space-y-4 px-2">
          <p className="text-sm font-semibold text-zinc-400 mb-3 ml-1 uppercase tracking-wider text-xs">Com o PromptAI Studio você acessa:</p>
          {[
            "Prompts testados para ChatGPT, Claude, Gemini, Flow, Whisk e outras IAs.",
            "Packs completos para vídeos, imagens, roteiros, títulos e narrações.",
            "Sugira e vote em novos prompts.",
            "Conteúdos Plus exclusivos."
          ].map((text, i) => (
            <div key={i} className="flex items-start gap-3 text-sm text-zinc-300">
              <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-[2px]">
                <Check className="h-3 w-3 text-primary-light" />
              </div>
              <p className="leading-snug text-zinc-400">{text}</p>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
