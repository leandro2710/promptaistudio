import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Settings as SettingsIcon, LogOut, Info, Palette, 
  Trash2, Bell, MessageCircle, AlertCircle, ChevronRight,
  Send, Sparkles, Lock, CheckCircle2
} from "lucide-react";
import { auth, signOut } from "@/src/lib/firebase";
import { useAuth } from "@/src/hooks/useAuth";
import { useAppearance } from "@/src/hooks/useAppearance";
import { submitSuggestion as submitSuggestionApi, submitReport as submitReportApi } from "@/src/services/feedbackService";
import toast from "react-hot-toast";
import { Button } from "@/src/components/ui/Button";
import { Crown } from "lucide-react";
import { PromptAILogo } from "@/src/components/brand/PromptAILogo";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const suggestionSchema = z.object({
  suggestion: z.string().min(10, "A sugestão precisa ter no mínimo 10 caracteres para podermos entender bem sua ideia.")
});

const reportSchema = z.object({
  report: z.string().min(15, "Por favor, detalhe mais o problema. Mínimo de 15 caracteres.")
});

type SuggestionInputs = z.infer<typeof suggestionSchema>;
type ReportInputs = z.infer<typeof reportSchema>;

export function Settings() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const appearance = useAppearance();

  const [showAppearance, setShowAppearance] = useState(false);
  const [showSuggest, setShowSuggest] = useState(false);
  const [showReport, setShowReport] = useState(false);

  const [submitting, setSubmitting] = useState(false);

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/login");
  };

  const handleChangeTheme = (t: string) => {
    if ((t === 'silver' || t === 'gold' || t === 'diamante' || t === 'ruby') && !user?.isPlus) {
      toast("Você não pode usar este tema por não ser um usuário Plus.", { icon: "✨" });
      return;
    }
    appearance.setTheme(t as any);
  };

  const handleChangeFontSize = (sz: string) => {
    appearance.setFontSize(sz as any);
  };

  const [showSuggestSuccess, setShowSuggestSuccess] = useState(false);
  const [showReportSuccess, setShowReportSuccess] = useState(false);

  const { register: regSuggest, handleSubmit: handleSuggestSubmit, reset: resetSuggest, formState: { errors: errorsSuggest } } = useForm<SuggestionInputs>({
    resolver: zodResolver(suggestionSchema)
  });

  const { register: regReport, handleSubmit: handleReportSubmit, reset: resetReport, formState: { errors: errorsReport } } = useForm<ReportInputs>({
    resolver: zodResolver(reportSchema)
  });

  const onSubmitSuggestion = async (data: SuggestionInputs) => {
    if (!user) return;
    setSubmitting(true);
    try {
      await submitSuggestionApi(data.suggestion, user);
      setShowSuggest(false);
      resetSuggest();
      setShowSuggestSuccess(true);
    } catch (e: any) {
      toast.error("Erro ao enviar: " + (e.message || "Tente novamente."));
    }
    setSubmitting(false);
  };

  const handleClearCache = () => {
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith('promptai_') && !key.includes('theme') && !key.includes('appearance')) {
        localStorage.removeItem(key);
      }
    });
    toast.success("Cache limpo com sucesso!");
  };

  const onSubmitReport = async (data: ReportInputs) => {
    if (!user) return;
    setSubmitting(true);
    try {
      await submitReportApi(data.report, user);
      setShowReport(false);
      resetReport();
      setShowReportSuccess(true);
    } catch (e: any) {
      toast.error("Erro ao enviar: " + (e.message || "Tente novamente."));
    }
    setSubmitting(false);
  };

  const SettingRow = ({ icon: Icon, title, onClick, destructive = false, suffix = <ChevronRight className="h-4 w-4 text-zinc-500" /> }: any) => (
    <button 
      onClick={onClick}
      className={`w-full flex items-center justify-between p-4 bg-card hover:bg-card-hover transition-colors first:rounded-t-[20px] last:rounded-b-[20px] border-b border-white/5 ${destructive ? 'text-red-500' : 'text-zinc-200'}`}
    >
      <div className="flex items-center gap-3">
        <Icon className="h-5 w-5" />
        <span className="font-medium text-[15px]">{title}</span>
      </div>
      {suffix}
    </button>
  );

  return (
    <div className="space-y-8 pb-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight">Ajustes</h1>
        <p className="text-sm text-zinc-400">Configure sua experiência.</p>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-2 mb-2">Conta</h2>
          <div className="rounded-[20px] border border-white/5 overflow-hidden">
             <SettingRow 
               icon={SettingsIcon} 
               title="Meu Perfil" 
               onClick={() => navigate("/profile")} 
             />
          </div>
        </div>

        <div>
           <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-2 mb-2">Personalização</h2>
           <div className="rounded-[20px] border border-white/5 overflow-hidden">
             <SettingRow 
               icon={Palette} 
               title="Aparência" 
               onClick={() => {
                 setShowAppearance(true);
               }} 
             />
           </div>
        </div>
        
        <div>
           <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-2 mb-2">Suporte</h2>
           <div className="rounded-[20px] border border-white/5 overflow-hidden">
             <SettingRow icon={MessageCircle} title="Sugerir Prompt" onClick={() => setShowSuggest(true)} />
             <SettingRow icon={AlertCircle} title="Reportar Problema" onClick={() => setShowReport(true)} />
           </div>
        </div>

        <div>
           <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-2 mb-2">Sistema</h2>
           <div className="rounded-[20px] border border-white/5 overflow-hidden">
             <SettingRow icon={Trash2} title="Limpar Cache" onClick={handleClearCache} />
           </div>
        </div>

        <div>
           <h2 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-2 mb-2">Sobre</h2>
           <div className="rounded-[20px] border border-white/5 overflow-hidden">
             <SettingRow icon={Info} title="Sobre o PromptAI Studio" onClick={() => navigate("/about")} />
           </div>
        </div>

        {user && (
          <div className="pt-4">
             <SettingRow icon={LogOut} title="Sair da Conta" onClick={handleLogout} destructive={true} suffix={null} />
          </div>
        )}

      </div>

      {showAppearance && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-md sm:items-center">
          <div className="w-full max-w-md bg-card/80 backdrop-blur-2xl border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl h-[85vh] sm:h-auto overflow-y-auto animate-in slide-in-from-bottom flex flex-col">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">Personalizar Aparência</h2>
              <button onClick={() => setShowAppearance(false)} className="p-2 rounded-full hover:bg-white/5 transition-colors">✕</button>
            </div>

            <div className="space-y-8 flex-1">
              {/* Preview Box */}
              <div 
                className="w-full rounded-2xl border border-white/10 p-5 flex items-center gap-4 transition-colors duration-300 relative overflow-hidden"
                style={{ backgroundColor: `var(--color-card, #0d0d15)` }}
                data-theme={appearance.theme}
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/5 border border-white/10">
                  <PromptAILogo size={36} variant="glow" />
                </div>
                <div className="flex flex-col">
                  <span className="text-white font-bold text-lg">PromptAI Studio</span>
                  <span className="text-primary-light text-sm font-medium capitalize">{appearance.theme}</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-400 mb-3 uppercase tracking-wider text-[10px]">Temas do App</h3>
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { id: 'purple', name: 'Roxo', class: 'bg-[#7c3aed]', isPlus: false },
                    { id: 'blue', name: 'Azul', class: 'bg-[#2563eb]', isPlus: false },
                    { id: 'green', name: 'Verde', class: 'bg-[#10b981]', isPlus: false },
                    // { id: 'red', name: 'Vermelho', class: 'bg-[#ef4444]', isPlus: false },
                    { id: 'pink-flow', name: 'Ice Pink', class: 'bg-gradient-to-tr from-pink-300 to-pink-500', isPlus: false },
                    { id: 'ruby', name: 'Ruby', class: 'bg-gradient-to-tr from-rose-500 to-rose-700 shadow-inner', isPlus: true },
                    { id: 'gold', name: 'Ouro', class: 'bg-gradient-to-tr from-yellow-600 to-yellow-300 shadow-inner ring-1 ring-yellow-400/50', isPlus: true },
                    { id: 'silver', name: 'Prata', class: 'bg-gradient-to-tr from-zinc-400 to-zinc-200 shadow-inner', isPlus: true },
                    { id: 'diamante', name: 'Diamante', class: 'bg-gradient-to-tr from-cyan-400 via-blue-400 to-purple-400 shadow-inner', isPlus: true }
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => handleChangeTheme(t.id)}
                      className={`relative flex flex-col items-center justify-center p-2 rounded-2xl border transition-all ${appearance.theme === t.id ? 'border-primary bg-primary/10' : 'border-white/5 bg-card hover:bg-card-hover'}`}
                    >
                      {t.isPlus && !user?.isPlus && <div className="absolute top-1 right-1"><Lock className="w-3 h-3 text-white/50" /></div>}
                      <div className={`w-8 h-8 rounded-full mb-2 ${t.class}`} />
                      <span className={`text-[10px] font-medium leading-tight text-center ${t.isPlus ? 'text-white' : 'text-zinc-300'}`}>{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-400 mb-3 uppercase tracking-wider text-[10px]">Tamanho da Fonte</h3>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'small', name: 'A-' },
                    { id: 'normal', name: 'A' },
                    { id: 'large', name: 'A+' },
                  ].map(s => (
                    <button
                      key={s.id}
                      onClick={() => handleChangeFontSize(s.id)}
                      className={`py-3 px-3 rounded-2xl border text-sm font-medium transition-all ${appearance.fontSize === s.id ? 'border-primary bg-primary/10 text-primary-light' : 'border-white/5 bg-card hover:bg-card-hover text-zinc-300'}`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showSuggest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-card/80 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">Sugerir Prompt</h2>
              <button onClick={() => { setShowSuggest(false); resetSuggest(); }} className="p-2 rounded-full hover:bg-white/5 transition-colors">✕</button>
            </div>
            <p className="text-sm text-zinc-400 mb-4">Tem uma ideia incrível de prompt? Compartilhe conosco para adicionarmos ao app!</p>
            <form onSubmit={handleSuggestSubmit(onSubmitSuggestion)}>
              <div className="mb-4">
                <textarea
                  className={`w-full h-32 bg-background border ${errorsSuggest.suggestion ? 'border-red-500/50 focus:ring-red-500/50' : 'border-white/10 focus:ring-primary/50'} rounded-2xl p-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 resize-none transition-colors`}
                  placeholder="Descreva o objetivo do prompt e como ele deve funcionar..."
                  {...regSuggest("suggestion")}
                />
                {errorsSuggest.suggestion && (
                  <p className="text-red-400 text-xs mt-2 pl-2">{errorsSuggest.suggestion.message}</p>
                )}
              </div>
              <Button type="submit" className="w-full rounded-[14px]" disabled={submitting}>
                {submitting ? "Enviando..." : "Enviar Sugestão"} <Send className="w-4 h-4 ml-2" />
              </Button>
            </form>
          </div>
        </div>
      )}

      {showReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-card/80 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
               <h2 className="text-xl font-bold flex items-center gap-2">Reportar Problema</h2>
              <button onClick={() => { setShowReport(false); resetReport(); }} className="p-2 rounded-full hover:bg-white/5 transition-colors">✕</button>
            </div>
            <p className="text-sm text-zinc-400 mb-4">Encontrou algum problema ou erro? Conte-nos para que possamos corrigir rapidamente.</p>
            <form onSubmit={handleReportSubmit(onSubmitReport)}>
              <div className="mb-4">
                <textarea
                  className={`w-full h-32 bg-background border ${errorsReport.report ? 'border-red-500/50 focus:ring-red-500/50' : 'border-white/10 focus:ring-red-500/50'} rounded-2xl p-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 resize-none transition-colors`}
                  placeholder="Descreva o erro ou problema que você encontrou..."
                  {...regReport("report")}
                />
                {errorsReport.report && (
                  <p className="text-red-400 text-xs mt-2 pl-2">{errorsReport.report.message}</p>
                )}
              </div>
              <Button type="submit" className="w-full rounded-[14px]" variant="default" style={{ backgroundColor: '#ef4444' }} disabled={submitting}>
                {submitting ? "Enviando..." : "Reportar Problema"} <AlertCircle className="w-4 h-4 ml-2" />
              </Button>
            </form>
          </div>
        </div>
      )}
      {showSuggestSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-card/80 backdrop-blur-2xl border border-white/10 rounded-3xl p-8 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-full flex items-center justify-center mb-6">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Muito Obrigado!</h2>
            <p className="text-zinc-400 mb-8">
              Agradecemos sua sugestão! Nossa equipe irá avaliá-la para adicionarmos ao PromptAI Studio em breve. Se aprovada, seu nome aparecerá como autor do prompt sugerido.
            </p>
            <Button className="w-full rounded-[14px]" onClick={() => setShowSuggestSuccess(false)}>
              Voltar aos ajustes
            </Button>
          </div>
        </div>
      )}

      {showReportSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-card/80 backdrop-blur-2xl border border-white/10 rounded-3xl p-8 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-green-500/10 border border-green-500/20 rounded-full flex items-center justify-center mb-6">
              <CheckCircle2 className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Reporte Enviado!</h2>
            <p className="text-zinc-400 mb-8">
              Muito obrigado por nos ajudar a melhorar o PromptAI Studio. Já recebemos seu reporte e vamos trabalhar na correção o mais rápido possível.
            </p>
            <Button className="w-full rounded-[14px] bg-green-500 hover:bg-green-600 text-white" onClick={() => setShowReportSuccess(false)}>
              Voltar aos ajustes
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
