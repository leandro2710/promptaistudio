import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Package, Check, Share2, Maximize2, X, Crown, Star } from "lucide-react";
import { motion } from "motion/react";
import toast from "react-hot-toast";
import { Pack, Prompt } from "@/src/types";
import { getPackById } from "@/src/services/packService";
import { getPromptsByIds } from "@/src/services/promptService";
import { useAuth } from "@/src/hooks/useAuth";
import { usePlus } from "@/src/hooks/usePlus";
import { PromptCard } from "@/src/components/prompt/PromptCard";
import { PlusLockCard } from "@/src/components/prompt/PlusLockCard";
import { getConfigWithFallback } from "@/src/services/configService";
import { Badge } from "@/src/components/ui/Badge";

export function PackDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isPlus } = usePlus();
  
  const [pack, setPack] = useState<Pack | null>(null);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState<any>(null);
  const [isImageModalOpen, setImageModalOpen] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      setLoading(true);
      const [p, conf] = await Promise.all([getPackById(id), getConfigWithFallback()]);
      setConfig(conf);
      if (p) {
        setPack(p);

        // Ocultar prompts protegidos no PackDetail se não for assinante
        if (p.access === "free" || isPlus) {
          const fetched = await getPromptsByIds(p.promptIds || []);
          setPrompts(fetched);
        }
      }
      setLoading(false);
    };
    load();
  }, [id, user, isPlus]);

  const share = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: pack?.title, url }).catch(console.error);
    } else {
      navigator.clipboard.writeText(url);
      toast.success("Link copiado!");
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-white/50 animate-pulse mt-20">Carregando pack...</div>;
  }

  if (!pack || !pack.active) {
    return (
      <div className="p-8 text-center text-white/50 mt-20">
        <p>Pack não encontrado ou inativo.</p>
        <button onClick={() => navigate(-1)} className="mt-4 text-primary underline">Voltar</button>
      </div>
    );
  }

  const isLocked = pack.access === "plus" && !isPlus;

  return (
    <div className="pb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-6 mt-6">
        {/* Header Section */}
        <div>
          <div className="flex items-start gap-4 mb-4">
            {(pack.thumbnailURL || (pack as any).thumbnailUrl || pack.imageURL || (pack as any).imageUrl || pack.coverURL) ? (
              <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0 bg-white/5 border border-white/10 shadow-lg relative">
                <img src={pack.thumbnailURL || (pack as any).thumbnailUrl || pack.imageURL || (pack as any).imageUrl || pack.coverURL} alt={pack.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-2xl"></div>
              </div>
            ) : (
               <div className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-2xl flex items-center justify-center shadow-lg shrink-0">
                  <Package className="h-8 w-8 text-primary" />
               </div>
            )}
             <div className="flex-1">
                <div className="flex flex-wrap gap-2 mb-2">
                  {pack.access === "plus" ? <Badge variant="plus" className="text-[10px] flex items-center gap-1 uppercase py-0.5 px-1.5"><Crown className="w-2.5 h-2.5" /> Plus</Badge> : <Badge variant="outline" className="text-[10px] text-zinc-400 border-zinc-700 uppercase px-1.5 py-0">Grátis</Badge>}
                  {pack.featured && (
                    <Badge variant="default" className="text-[10px] bg-white text-black px-1.5 py-0 gap-1"><Star className="w-2.5 h-2.5 fill-current" /> Destaque</Badge>
                  )}
                  <Badge variant="secondary" className="text-[10px] gap-1 px-1.5 py-0"><Package className="h-2.5 w-2.5" /> {pack.promptIds?.length || 0} Prompts</Badge>
                </div>
                <h1 className="text-2xl font-bold tracking-tight leading-snug">{pack.title}</h1>
             </div>
          </div>
          
          <p className="text-zinc-300 text-[15px] leading-relaxed mb-4">{pack.description}</p>
          
          <div className="flex items-center gap-3 text-sm text-zinc-400 mb-6 flex-wrap">
            <span className="capitalize">{(pack as any).platform || "Geral"}</span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span className="capitalize">{pack.category || "Geral"}</span>
          </div>

          {pack.suggestedBy && pack.suggestedBy.name && (
            <div className="flex items-center gap-2 mt-4 px-3 py-2 rounded-xl bg-primary/5 border border-primary/10 w-fit">
              {pack.suggestedBy.photoURL ? (
                <img src={pack.suggestedBy.photoURL} alt={pack.suggestedBy.name} className="w-5 h-5 rounded-full object-cover" />
              ) : (
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center text-primary text-[9px] font-bold">
                  {pack.suggestedBy.name.charAt(0).toUpperCase()}
                </div>
              )}
              <span className="text-[11px] text-zinc-400 uppercase tracking-widest font-medium">
                Sugerido por <strong className="text-primary-light lowercase capitalize">{pack.suggestedBy.name}</strong>
              </span>
            </div>
          )}
        </div>

        {/* Content Section */}
        <div className="space-y-6">
          
          {((pack.benefits && pack.benefits.length > 0) || pack.imageURL) && (
            <div className="bg-card rounded-[2rem] border border-white/5 p-6 space-y-6">
               {(pack.benefits && pack.benefits.length > 0) && (
                 <div>
                   <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">O que inclui neste pacote</h3>
                   <ul className="space-y-3">
                     {pack.benefits.map((b, i) => (
                       <li key={i} className="flex gap-3 text-[15px] text-zinc-300 items-start">
                         <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                         <span>{b}</span>
                       </li>
                     ))}
                   </ul>
                 </div>
               )}

               {pack.imageURL && (
                 <div className={(pack.benefits && pack.benefits.length > 0) ? "pt-6 border-t border-white/5" : ""}>
                   <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Imagem de Exemplo</h3>
                   <div className="relative rounded-2xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setImageModalOpen(true)}>
                     <img src={pack.imageURL} alt="Exemplo" className="w-full h-auto object-cover" />
                     <div className="absolute inset-0 bg-black/40 xl:opacity-0 xl:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4">
                       <div className="bg-black/60 backdrop-blur-md rounded-full p-3 text-white">
                         <Maximize2 className="w-5 h-5" />
                       </div>
                     </div>
                   </div>
                 </div>
               )}
            </div>
          )}

          <div className="bg-card rounded-[2rem] border border-white/5 p-6 space-y-6">
            {isLocked ? (
               <div>
                 <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-4">Prompts do Pacote</h3>
                 <div className="relative">
                    <div className="grid gap-3 opacity-20 pointer-events-none blur-[2px]">
                       {Array.from({length: 3}).map((_, i) => (
                          <div key={i} className="h-28 bg-white/5 rounded-2xl w-full border border-white/10" />
                       ))}
                    </div>
                    <div className="absolute inset-0 z-10 flex items-center justify-center p-4">
                       <PlusLockCard config={config} />
                    </div>
                 </div>
               </div>
            ) : (
              <div>
                <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-4">Explore os {prompts.length} Prompts</h3>
                <div className="grid gap-4">
                  {prompts.length > 0 ? prompts.map(p => (
                    <PromptCard key={p.id} prompt={p} />
                  )) : (
                    <div className="text-center py-8 bg-white/5 rounded-2xl border border-white/5">
                       <p className="text-sm text-zinc-400">Os prompts deste pacote ainda não foram adicionados.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {isImageModalOpen && pack.imageURL && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4" onClick={() => setImageModalOpen(false)}>
           <button className="absolute top-4 right-4 text-white hover:bg-white/10 rounded-full p-2" onClick={(e) => { e.stopPropagation(); setImageModalOpen(false); }}>
             <X className="w-6 h-6" />
           </button>
           <img src={pack.imageURL} alt="Exemplo Completo" className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}
