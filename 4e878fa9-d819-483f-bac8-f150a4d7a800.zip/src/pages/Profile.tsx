import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User as UserIcon, LogOut, ArrowRight, ShieldCheck, Edit2, Save, X, Sparkles, CheckCircle2, Image as ImageIcon, Code2, Video, Terminal, Bot, Palette, Megaphone, BookOpen } from "lucide-react";
import { useAuth } from "@/src/hooks/useAuth";
import { usePlus } from "@/src/hooks/usePlus";
import { signOut, auth, db } from "@/src/lib/firebase";
import { doc, updateDoc } from "firebase/firestore";
import { Button } from "@/src/components/ui/Button";
import { GlassCard } from "@/src/components/ui/GlassCard";
import { Badge } from "@/src/components/ui/Badge";
import { Crown } from "lucide-react";
import { format } from "date-fns";
import toast from "react-hot-toast";

const TAG_OPTIONS = [
  { id: 'Dev', icon: Code2, label: 'Dev' },
  { id: 'Criador de Conteúdo', icon: Video, label: 'Criador de Conteúdo' },
  { id: 'Prompt Engineer', icon: Terminal, label: 'Prompt Engineer' },
  { id: 'Entusiasta de IA', icon: Bot, label: 'Entusiasta de IA' },
  { id: 'Designer', icon: Palette, label: 'Designer' },
  { id: 'Marketeiro', icon: Megaphone, label: 'Marketeiro' },
  { id: 'Estudante', icon: BookOpen, label: 'Estudante' },
  { id: '', icon: X, label: 'Nenhuma' },
];

export function Profile() {
  const { user } = useAuth();
  const { isPlus, userRole, status } = usePlus();
  const navigate = useNavigate();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [photoURL, setPhotoURL] = useState(user?.photoURL || "");
  const [userTag, setUserTag] = useState(user?.userTag || "");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    
    setUploading(true);

    try {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          const MAX_WIDTH = 256;
          const MAX_HEIGHT = 256;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx?.drawImage(img, 0, 0, width, height);

          // Get base64 string, lower quality to ensure it fits in Firestore easily
          const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
          setPhotoURL(dataUrl);
          setUploading(false);
          toast.success("Foto carregada com sucesso!");
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      toast.error("Erro ao processar imagem.");
      setUploading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/login");
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      // NOTE: Never send role, isPlus, plusUntil, status here
      await updateDoc(doc(db, 'users', user.uid), {
        name,
        photoURL,
        userTag,
        updatedAt: new Date()
      });
      toast.success("Perfil atualizado! Recarregue caso a foto demore.");
      setIsEditing(false);
    } catch (e: any) {
      toast.error("Erro ao salvar: " + (e.message || "Tente novamente."));
    }
    setSaving(false);
  };

  if (!user) {
    return (
      <div className="space-y-6 pb-8 text-center pt-20">
        <div className="h-20 w-20 bg-card rounded-full flex items-center justify-center mx-auto mb-6 border border-white/5">
          <UserIcon className="h-8 w-8 text-zinc-500" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Perfil</h1>
        <p className="text-zinc-400 mb-8">Faça login para gerenciar sua conta.</p>
        <Button onClick={() => navigate("/login")}>Fazer Login</Button>
      </div>
    );
  }

  if (status === 'blocked') {
    return (
      <div className="p-8 text-center space-y-4">
        <h2 className="text-xl font-bold text-red-500">Conta Bloqueada</h2>
        <p className="text-zinc-400">Sua conta foi suspensa. Entre em contato com o suporte para mais informações.</p>
      </div>
    );
  }

  const getExpirationDate = () => {
    if (!user.plusUntil) return null;
    const date = typeof user.plusUntil.toDate === 'function' 
      ? user.plusUntil.toDate() 
      : new Date((user.plusUntil as any).seconds * 1000);
    return format(date, "dd/MM/yyyy");
  };

  // Check if Plus expired
  const isExpiredPlus = !isPlus && user.plusUntil && (new Date() > (typeof user.plusUntil.toDate === 'function' ? user.plusUntil.toDate() : new Date((user.plusUntil as any).seconds * 1000)));

  return (
    <div className="space-y-6 pb-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-tight">Perfil</h1>
        {!isEditing ? (
          <button onClick={() => setIsEditing(true)} className="p-2 text-primary hover:bg-primary/10 rounded-full transition-colors">
            <Edit2 className="w-5 h-5" />
          </button>
        ) : (
          <button onClick={() => setIsEditing(false)} className="p-2 text-zinc-400 hover:bg-white/5 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>
      
      <GlassCard className="flex flex-col p-6 border-white/10 relative overflow-hidden">
        {isPlus && <div className="absolute inset-0 bg-primary/5 blur-3xl" />}
        
        {isEditing ? (
          <div className="space-y-4 relative z-10 w-full">
            <div>
              <label className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-1 block">Nome</label>
              <input 
                type="text" 
                value={name} 
                onChange={e => setName(e.target.value)} 
                className="w-full bg-background border border-white/10 rounded-2xl p-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-1 flex justify-between">
                <span>Foto de Perfil</span>
                {uploading && <span className="text-primary animate-pulse w-full text-right ml-2">Enviando...</span>}
              </label>
              <div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  id="photo-upload"
                  onChange={handlePhotoUpload}
                  disabled={uploading}
                />
                <label
                  htmlFor="photo-upload"
                  className={`w-full bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-2xl p-3 text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <ImageIcon className="w-5 h-5" />
                  <span>{photoURL ? "Alterar foto" : "Escolher na galeria"}</span>
                </label>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-2 block">Tag do Usuário</label>
              <div className="flex flex-wrap gap-2">
                {TAG_OPTIONS.map((option) => {
                  const Icon = option.icon;
                  const isSelected = userTag === option.id;
                  return (
                    <button
                      key={option.id}
                      onClick={() => setUserTag(option.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-colors border ${
                        isSelected 
                          ? 'bg-primary/20 text-primary-light border-primary/50' 
                          : 'bg-white/5 text-zinc-400 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <Button className="w-full rounded-[14px] mt-2" onClick={handleSave} disabled={saving}>
              {saving ? "Salvando..." : "Salvar Alterações"} <Save className="w-4 h-4 ml-2" />
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center text-center">
            <div className="h-24 w-24 rounded-full overflow-hidden mb-4 border-2 border-white/10 relative z-10">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.name} className="h-full w-full object-cover" />
              ) : (
                <div className="h-full w-full bg-zinc-800 flex items-center justify-center">
                  <UserIcon className="h-10 w-10 text-zinc-400" />
                </div>
              )}
            </div>
            
            <h2 className="text-xl font-bold relative z-10">{user.name}</h2>
            {user.userTag && (() => {
              const matchedTag = TAG_OPTIONS.find(t => t.id === user.userTag);
              const TagIcon = matchedTag?.icon;
              return (
                <span className="text-[10px] uppercase font-bold text-primary-light border border-primary/20 bg-primary/10 px-2 py-0.5 rounded-full mt-1 mb-1 relative z-10 flex items-center gap-1">
                  {TagIcon && <TagIcon className="w-3 h-3" />}
                  {matchedTag ? matchedTag.label : user.userTag}
                </span>
              );
            })()}
            <p className="text-sm text-zinc-400 mb-4 relative z-10">{user.email}</p>
            
            <div className="flex flex-col gap-2 relative z-10 items-center">
              {userRole === 'admin' ? (
                 <Badge variant="plus" className="gap-1 px-3 py-1 shadow-md bg-zinc-800 text-white border-zinc-600 font-bold"><ShieldCheck className="h-4 w-4" /> Administrador</Badge>
              ) : isPlus ? (
                <Badge variant="plus" className="gap-1 px-3 py-1 shadow-lg font-bold flex items-center">
                  <Crown className="w-4 h-4 mr-1" /> Assinante Plus
                </Badge>
              ) : isExpiredPlus ? (
                <Badge variant="outline" className="border-red-500/30 text-red-400 bg-red-500/10">Plus Expirado</Badge>
              ) : (
                <Badge variant="outline" className="border-white/10 bg-white/5 uppercase">Grátis</Badge>
              )}
              
              {isPlus && user.plusUntil && userRole !== 'admin' && (
                <span className="text-xs text-zinc-500 mt-2 font-medium">Válido até {getExpirationDate()}</span>
              )}
            </div>
          </div>
        )}
      </GlassCard>

      <div className="space-y-4">
        <h2 className="text-sm font-semibold tracking-tight text-zinc-300 pl-1">Seu Plano e Benefícios</h2>
        
        <GlassCard className="p-0 overflow-hidden border border-white/5">
           {isPlus || userRole === 'admin' ? (
             <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-300 shadow-sm border border-yellow-400/50 flex items-center justify-center text-yellow-950">
                    <Crown className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-white">Plano Plus Ativo</h3>
                    <p className="text-xs text-zinc-400">Você tem acesso ilimitado.</p>
                  </div>
                </div>
                <ul className="space-y-3 mt-6">
                  {['Temas exclusivos', 'Prompts exclusivos', 'Packs exclusivos', 'Conteúdo avançado', 'Novos conteúdos frequentes'].map(ben => (
                    <li key={ben} className="flex items-start gap-2 text-sm text-zinc-300">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      {ben}
                    </li>
                  ))}
                </ul>
             </div>
           ) : (
             <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-zinc-400">
                    <UserIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-white">Plano Grátis</h3>
                    <p className="text-xs text-zinc-400">Acesso básico aos conteúdos.</p>
                  </div>
                </div>
                <ul className="space-y-3 mt-6">
                  {['Acesso a Prompts Grátis', 'Acesso a Packs Grátis', 'Busca e Categorias'].map(ben => (
                    <li key={ben} className="flex items-start gap-2 text-sm text-zinc-400">
                      <CheckCircle2 className="w-4 h-4 text-zinc-500 shrink-0 mt-0.5" />
                      {ben}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 pt-6 border-t border-white/5">
                  <Button variant="plus" className="w-full justify-between px-6 rounded-[14px]" onClick={() => navigate("/plus")}>
                    <span className="flex items-center gap-2"><Crown className="w-4 h-4" /> Desbloquear o Plus</span> <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
             </div>
           )}
        </GlassCard>
        
        {userRole === 'admin' && (
          <GlassCard className="p-4 text-sm text-zinc-400 text-center border-primary/20 bg-primary/5">
            Administrador do ecossistema. Use o app PromptAI Admin para gerenciar os conteúdos.
          </GlassCard>
        )}
      </div>

      <Button variant="outline" className="w-full text-red-500 hover:text-red-400 hover:bg-red-500/10 border-white/5 rounded-[14px]" onClick={handleLogout}>
        <LogOut className="h-4 w-4 mr-2" /> Sair
      </Button>
    </div>
  );
}
