import { useEffect, useState, useMemo } from "react";
import { SearchIcon, Filter } from "lucide-react";
import { Prompt } from "@/src/types";
import { searchPromptsLocally } from "@/src/services/promptService";
import { PromptCard } from "@/src/components/prompt/PromptCard";
import { BaseCard } from "@/src/components/ui/BaseCard";
import { Button } from "@/src/components/ui/Button";
import { useNavigate } from "react-router-dom";
import { usePaginatedCollection } from "@/src/hooks/usePaginatedCollection";
import { InfiniteScrollObserver } from "@/src/components/ui/InfiniteScrollObserver";
import { query, collection, where } from "firebase/firestore";
import { db } from "@/src/lib/firebase";

import { cn } from "@/src/lib/utils";

const FilterPill = ({ active, children, onClick }: any) => (
  <button 
    onClick={onClick}
    className={cn(
      "px-4 min-h-[44px] rounded-2xl text-[13px] font-medium whitespace-nowrap transition-all duration-200 border flex items-center",
      active 
        ? "bg-primary text-white border-primary shadow-md shadow-primary/20" 
        : "bg-card text-zinc-400 border-white/5 hover:bg-card-hover hover:text-zinc-200"
    )}
  >
    {children}
  </button>
);

export function Prompts() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "free" | "plus" | "featured" | "novos">("all");
  const [activePlatform, setActivePlatform] = useState<string>("all");
  const navigate = useNavigate();

  const baseQuery = useMemo(() => {
    let q = query(collection(db, 'prompts'), where('active', '==', true));
    if (filter === "free") q = query(q, where('access', '==', 'free'));
    if (filter === "plus") q = query(q, where('access', '==', 'plus'));
    if (filter === "featured") q = query(q, where('featured', '==', true));
    // Cannot do "novos" or "activePlatform" on DB easily without complex indices, handled locally
    return q;
  }, [filter]);

  const { items, isLoading, hasMore, loadMore, error } = usePaginatedCollection<Prompt>(baseQuery, 12);

  // Derive platforms from the prompts loaded
  const availablePlatforms = useMemo(() => {
    const platforms = new Set<string>();
    items.forEach(prompt => {
       const plat = prompt.platform || "Geral";
       platforms.add(plat);
    });
    return Array.from(platforms).sort();
  }, [items]);

  const filteredPrompts = useMemo(() => {
    let result = items;
    
    // Sort locally by date because we didn't orderBy in DB to avoid index issues
    result = [...result].sort((a,b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));

    if (filter === "novos") {
      result = result.filter(p => p.createdAt && (Date.now() - p.createdAt.toMillis() < 7 * 24 * 60 * 60 * 1000));
    }

    // Platform Filter
    if (activePlatform !== "all") {
      result = result.filter(p => (p.platform || "Geral") === activePlatform);
    }
    
    if (search) {
      result = searchPromptsLocally(result, search);
    }
    return result;
  }, [items, filter, activePlatform, search]);

  // Initial load
  useEffect(() => {
    loadMore();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseQuery]);

  const clearFilters = () => {
    setSearch("");
    setActivePlatform("all");
    setFilter("all");
  };

  const hasActiveFilters = activePlatform !== "all" || filter !== "all" || search;

  return (
    <div className="space-y-6 pb-8">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight">Explorar Prompts</h1>
        <p className="text-sm text-zinc-400">Encontre o prompt ideal para sua necessidade.</p>
      </div>

      <div className="relative z-[20] w-full mt-4 mb-4">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-[30]" />
        <input 
          type="text" 
          placeholder="Buscar..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="relative z-[10] w-full h-12 bg-card border border-white/5 rounded-2xl pl-12 pr-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-primary/50"
        />
      </div>

      <div className="flex flex-col gap-1">
        {/* Chips for Access/Status */}
        <div className="relative -mx-4 sm:mx-0 w-[calc(100%+2rem)] sm:w-full [mask-image:linear-gradient(to_right,transparent,black_16px,black_calc(100%-16px),transparent)]">
          <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar px-5 sm:px-4">
            <FilterPill active={filter === "all"} onClick={() => setFilter("all")}>Todos</FilterPill>
            <FilterPill active={filter === "free"} onClick={() => setFilter("free")}>Grátis</FilterPill>
            <FilterPill active={filter === "plus"} onClick={() => setFilter("plus")}>Plus</FilterPill>
            <FilterPill active={filter === "novos"} onClick={() => setFilter("novos")}>Novos</FilterPill>
            <FilterPill active={filter === "featured"} onClick={() => setFilter("featured")}>Destaques</FilterPill>
          </div>
        </div>

        {/* Categories Chips */}
        {availablePlatforms.length > 0 && (
          <div className="relative -mx-4 sm:mx-0 w-[calc(100%+2rem)] sm:w-full [mask-image:linear-gradient(to_right,transparent,black_16px,black_calc(100%-16px),transparent)]">
            <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar px-5 sm:px-4">
              <FilterPill 
                active={activePlatform === "all"} 
                onClick={() => setActivePlatform("all")}
              >
                Todas
              </FilterPill>
              {availablePlatforms.map(plat => {
                let displayName = plat;
                if (plat.toLowerCase() === "google-ai-studio" || plat.toLowerCase() === "google ai studio" || plat.toLowerCase() === "gemini") displayName = "Gemini";
                if (plat.toLowerCase() === "chatgpt") displayName = "ChatGPT";
                
                return (
                  <FilterPill 
                    key={plat} 
                    active={activePlatform === plat} 
                    onClick={() => setActivePlatform(plat)}
                  >
                    <span className="capitalize">{displayName}</span>
                  </FilterPill>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {hasActiveFilters && (
        <div className="flex justify-end">
          <button onClick={clearFilters} className="text-xs text-zinc-400 hover:text-white transition-colors">Limpar filtros</button>
        </div>
      )}

      {error ? (
        <div className="p-4 bg-red-500/10 text-red-400 rounded-2xl text-center text-sm">{error.message || "Erro ao carregar prompts"}</div>
      ) : isLoading && items.length === 0 ? (
        <div className="grid gap-4">
          {Array.from({length: 4}).map((_, i) => <BaseCard.Skeleton key={i} />)}
        </div>
      ) : filteredPrompts.length > 0 ? (
        <>
          <div className="grid gap-4">
            {filteredPrompts.map(prompt => (
              <PromptCard key={prompt.id} prompt={prompt} />
            ))}
          </div>
          <InfiniteScrollObserver hasMore={hasMore} isLoading={isLoading} onIntersect={loadMore} />
        </>
      ) : (
        <div className="p-12 text-center text-zinc-500 text-sm flex flex-col items-center bg-card rounded-3xl border border-white/5">
          <SearchIcon className="h-8 w-8 mb-3 opacity-20" />
          <p className="mb-4">Nenhum prompt encontrado.</p>
          <div className="flex flex-col sm:flex-row gap-2">
            {hasActiveFilters && (
               <Button variant="secondary" onClick={clearFilters} size="sm">Limpar Filtros</Button>
            )}
            <Button variant="default" onClick={() => navigate('/categories')} size="sm">Ver Categorias</Button>
          </div>
        </div>
      )}
    </div>
  );
}
