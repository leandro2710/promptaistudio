import { useEffect, useState } from "react";
import { Update } from "@/src/types";
import { getActiveUpdates } from "@/src/services/updateService";
import { GlassCard } from "@/src/components/ui/GlassCard";
import { Badge } from "@/src/components/ui/Badge";
import { format } from "date-fns";
import { Zap, ArrowRight, Terminal, Package, ChevronRight, Download, Sparkles, Wrench, Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/src/components/ui/Button";

export function Updates() {
  const [updates, setUpdates] = useState<Update[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const res = await getActiveUpdates();
      setUpdates(res);
      setLoading(false);
    };
    load();
  }, []);

  const getVariant = (type: string) => {
    switch (type) {
      case 'prompt': return 'plus'; // using plus style for new content
      case 'pack': return 'plus';
      case 'feature': return 'success';
      case 'news': return 'default';
      case 'warning': return 'warning';
      case 'maintenance': return 'outline';
      case 'update': return 'success';
      default: return 'secondary';
    }
  };

  const getUpdateLabel = (type: string) => {
    switch (type) {
      case 'prompt': return 'Novo Prompt';
      case 'pack': return 'Novo Pack';
      case 'feature': return 'Melhoria de App';
      case 'warning': return 'Aviso Importante';
      case 'maintenance': return 'Manutenção';
      case 'update': return 'Ajuste/Correção de bug';
      case 'news': return 'Conteúdo Plus';
      default: return 'Novidade';
    }
  };

  const getUpdateIcon = (type: string) => {
    switch (type) {
      case 'prompt': return <Terminal className="h-4 w-4" />;
      case 'pack': return <Package className="h-4 w-4" />;
      case 'feature': return <Sparkles className="h-4 w-4" />;
      case 'maintenance': return <Wrench className="h-4 w-4" />;
      case 'update': return <Zap className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  }

  const renderCTA = (update: Update) => {
    if (update.targetCollection === "prompts" && update.targetId) {
      return (
        <Button variant="secondary" className="w-full mt-4 justify-between" onClick={() => navigate(`/prompt/${update.targetId}`)}>
          Visualizar Prompt <ArrowRight className="h-4 w-4" />
        </Button>
      );
    }
    if (update.targetCollection === "packs" && update.targetId) {
      return (
        <Button variant="secondary" className="w-full mt-4 justify-between" onClick={() => navigate(`/pack/${update.targetId}`)}>
          Visualizar Pack <ArrowRight className="h-4 w-4" />
        </Button>
      );
    }
    if (update.targetCollection === "external" && update.downloadURL) {
      return (
        <Button variant="default" className="w-full mt-4 justify-between" onClick={() => window.open(update.downloadURL, "_blank")}>
          Acessar Link <ArrowRight className="h-4 w-4" />
        </Button>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Bell className="h-6 w-6 text-primary drop-shadow-[0_0_8px_rgba(var(--color-primary),0.5)] fill-primary/20" />
          Novidades
        </h1>
        <p className="text-sm text-zinc-400">Acompanhe as últimas atualizações do app, correções e novos conteúdos exclusivos.</p>
      </div>

      {loading ? (
        <div className="grid gap-4">
          {Array.from({length: 3}).map((_, i) => <div key={i} className="animate-pulse h-40 bg-white/5 rounded-3xl" />)}
        </div>
      ) : updates.length > 0 ? (
         <div className="space-y-6 relative before:absolute before:inset-0 before:left-[11px] before:-translate-x-px before:h-full before:w-[2px] before:bg-gradient-to-b before:from-transparent before:via-white/5 before:to-transparent">
           {updates.map(update => (
             <div key={update.id} className="relative pl-8">
                <div className="absolute left-[3px] top-7 h-4 w-4 rounded-full bg-primary border-4 border-background flex items-center justify-center shadow-[0_0_10px_rgba(var(--color-primary),0.5)] z-10">
                  <div className="w-1.5 h-1.5 bg-background rounded-full" />
                </div>
                
                <GlassCard className="p-6 border-white/5 transition-all hover:border-white/10 relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                  
                  <div className="flex justify-between items-start mb-4 gap-2 flex-wrap">
                    <Badge variant={getVariant(update.type) as any} className="gap-1.5 py-1 px-3">
                      {getUpdateIcon(update.type)}
                      {getUpdateLabel(update.type)}
                    </Badge>
                    <span className="text-xs text-zinc-500 font-medium">
                      {update.createdAt && format(update.createdAt.toMillis ? update.createdAt.toMillis() : (update.createdAt as any).seconds * 1000, 'dd/MM/yyyy')}
                    </span>
                  </div>
                  
                  <h3 className="font-bold text-xl mb-2 text-white">{update.title}</h3>
                  <p className="text-zinc-400 text-[15px] whitespace-pre-line leading-relaxed">{update.message}</p>
                  
                  {renderCTA(update)}
                </GlassCard>
             </div>
           ))}
         </div>
      ) : (
        <div className="py-16 px-6 text-center border border-white/5 rounded-[2rem] bg-card flex flex-col items-center justify-center">
          <Bell className="h-10 w-10 mb-4 text-zinc-600 opacity-50" />
          <h3 className="font-display font-bold text-lg text-zinc-300 mb-2">Tudo quieto por aqui — em breve novos conteúdos chegando ✦</h3>
          <p className="opacity-60 text-sm text-zinc-400">Ative as notificações para ser o primeiro a saber.</p>
        </div>
      )}
    </div>
  );
}
