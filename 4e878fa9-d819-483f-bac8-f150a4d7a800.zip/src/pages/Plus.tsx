import { useEffect, useState } from "react";
import { Sparkles, MessageCircle, Check } from "lucide-react";
import { AppConfig } from "@/src/types";
import { getConfigWithFallback } from "@/src/services/configService";
import { Button } from "@/src/components/ui/Button";

import { Crown } from "lucide-react";

const benefits = [
  "Temas exclusivos",
  "Prompts exclusivos",
  "Packs exclusivos",
  "Conteúdo avançado",
  "Novos conteúdos adicionados com frequência"
];

export function Plus() {
  const [config, setConfig] = useState<AppConfig | null>(null);

  useEffect(() => {
    getConfigWithFallback().then(setConfig);
  }, []);

  const handleWhatsApp = () => {
    if (config?.whatsappNumber) {
      const msg = encodeURIComponent(config.whatsappMessage || 'Olá, quero assinar o Plus.');
      window.open("https://wa.me/" + config.whatsappNumber + "?text=" + msg, '_blank');
    }
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="rounded-[2.5rem] bg-card border border-white/5 p-8 relative overflow-hidden backdrop-blur-xl">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent" />
        
        <div className="relative z-10 flex flex-col h-full">
          <div className="mb-8">
            <span className="text-yellow-500 font-semibold tracking-wide text-sm uppercase">Assinatura Plus</span>
            <div className="mt-2 flex items-baseline text-4xl font-extrabold text-white">
              {config?.plusPrice || "R$ 9,90"}
              <span className="ml-1 text-xl font-medium text-zinc-500">/mês</span>
            </div>
            <p className="text-sm text-zinc-400 mt-1">menos de R$ 0,35 ao dia</p>
          </div>
          
          <ul className="space-y-4 mb-8">
            {benefits.map((benefit, i) => (
              <li key={i} className="flex gap-3 text-sm text-zinc-300">
                <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-yellow-500/20 mt-0.5 border border-yellow-500/20">
                  <Check className="h-3 w-3 text-yellow-400" />
                </div>
                {benefit}
              </li>
            ))}
          </ul>
          
          <Button onClick={handleWhatsApp} variant="plus" size="lg" className="w-full mt-auto shadow-xl font-bold">
            Assinar
          </Button>
          <p className="text-center text-xs text-zinc-500 mt-4">
            A liberação do acesso é feita manualmente após confirmação de pagamento.
          </p>
        </div>
      </div>
    </div>
  );
}
