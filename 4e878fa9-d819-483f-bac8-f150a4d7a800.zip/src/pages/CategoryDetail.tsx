import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Prompt, Category } from "@/src/types";
import { getPromptsByCategory } from "@/src/services/promptService";
import { getCategoryBySlug } from "@/src/services/categoryService";
import { PromptCard } from "@/src/components/prompt/PromptCard";
import { ArrowLeft } from "lucide-react";

export function CategoryDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [category, setCategory] = useState<Category | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!slug) return;
      setLoading(true);
      const [cat, pts] = await Promise.all([
        getCategoryBySlug(slug),
        getPromptsByCategory(slug)
      ]);
      setCategory(cat);
      setPrompts(pts);
      setLoading(false);
    };
    load();
  }, [slug]);

  return (
    <div className="space-y-6 pb-8 animate-in fade-in">
      <div className="flex items-center gap-4 mb-2">
        <button onClick={() => navigate(-1)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-card hover:bg-card-hover border border-white/5">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex-1 overflow-hidden">
          {loading ? (
             <div className="h-6 w-32 bg-white/5 rounded animate-pulse" />
          ) : (
             <h1 className="text-xl font-bold tracking-tight truncate">{category?.name || "Categoria"}</h1>
          )}
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4">
          {Array.from({length: 6}).map((_, i) => <div key={i} className="animate-pulse h-32 bg-white/5 rounded-3xl" />)}
        </div>
      ) : prompts.length > 0 ? (
        <div className="grid gap-4">
          {prompts.map(prompt => (
            <div key={prompt.id} className="h-full">
              <PromptCard prompt={prompt} />
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center text-zinc-500 text-sm">
          Nenhum prompt encontrado nesta categoria.
        </div>
      )}
    </div>
  );
}
