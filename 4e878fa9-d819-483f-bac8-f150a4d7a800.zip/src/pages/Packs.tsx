import { useState, useMemo, useEffect } from "react";
import { Pack } from "@/src/types";
import { PackCard } from "@/src/components/pack/PackCard";
import { BaseCard } from "@/src/components/ui/BaseCard";
import { Button } from "@/src/components/ui/Button";
import { Package, SearchIcon } from "lucide-react";
import { usePaginatedCollection } from "@/src/hooks/usePaginatedCollection";
import { InfiniteScrollObserver } from "@/src/components/ui/InfiniteScrollObserver";
import { query, collection, where } from "firebase/firestore";
import { db } from "@/src/lib/firebase";

import { cn } from "@/src/lib/utils";

const FilterPill = ({ active, children, onClick }: any) => (
  <button 
    onClick={onClick}
    className={cn(
      "px-4 min-h-[44px] rounded-2xl text-[13px] font-medium whitespace-nowrap transition-all duration-200 border flex items-center",
      active 
        ? "bg-primary text-white border-primary shadow-md shadow-primary/20" 
        : "bg-card text-zinc-400 border-white/5 hover:bg-card-hover hover:text-zinc-200"
    )}
  >
    {children}
  </button>
);

export function Packs() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "free" | "plus" | "featured" | "novos">("all");
  const [activePlatform, setActivePlatform] = useState<string>("all");

  const baseQuery = useMemo(() => {
    let q = query(collection(db, 'packs'), where('active', '==', true));
    if (filter === "free") q = query(q, where('access', '==', 'free'));
    if (filter === "plus") q = query(q, where('access', '==', 'plus'));
    if (filter === "featured") q = query(q, where('featured', '==', true));
    return q;
  }, [filter]);

  const { items, isLoading, hasMore, loadMore, error } = usePaginatedCollection<Pack>(baseQuery, 12);

  // Derive platforms from the packs loaded
  const availablePlatforms = useMemo(() => {
    const platforms = new Set<string>();
    items.forEach(pack => {
       const plat = (pack as any).platform || "Geral";
       platforms.add(plat);
    });
    return Array.from(platforms).sort();
  }, [items]);

  const filteredPacks = useMemo(() => {
    let result = items;
    
    result = [...result].sort((a,b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));

    if (filter === "novos") {
      result = result.filter(p => p.createdAt && (Date.now() - p.createdAt.toMillis() < 7 * 24 * 60 * 60 * 1000));
    }

    // Platform Filter
    if (activePlatform !== "all") {
      result = result.filter(p => ((p as any).platform || "Geral") === activePlatform);
    }
    
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(p => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    }

    return result;
  }, [items, filter, activePlatform, search]);

  useEffect(() => {
    loadMore();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseQuery]);

  return (
    <div className="space-y-6 pb-8">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight">Explorar Packs</h1>
        <p className="text-sm text-zinc-400">Coleções completas de prompts organizados por objetivo.</p>
      </div>

      <div className="relative z-[20] w-full mt-4 mb-4">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-[30]" />
        <input 
          type="text" 
          placeholder="Buscar packs..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="relative z-[10] w-full h-12 bg-card border border-white/5 rounded-2xl pl-12 pr-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-primary/50"
        />
      </div>

      <div className="flex flex-col gap-1">
        <div className="relative -mx-4 sm:mx-0 w-[calc(100%+2rem)] sm:w-full [mask-image:linear-gradient(to_right,transparent,black_16px,black_calc(100%-16px),transparent)]">
          <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar px-5 sm:px-4">
            <FilterPill active={filter === "all"} onClick={() => setFilter("all")}>Todos</FilterPill>
            <FilterPill active={filter === "free"} onClick={() => setFilter("free")}>Grátis</FilterPill>
            <FilterPill active={filter === "plus"} onClick={() => setFilter("plus")}>Plus</FilterPill>
            <FilterPill active={filter === "novos"} onClick={() => setFilter("novos")}>Novos</FilterPill>
            <FilterPill active={filter === "featured"} onClick={() => setFilter("featured")}>Destaques</FilterPill>
          </div>
        </div>

        {availablePlatforms.length > 0 && (
          <div className="relative -mx-4 sm:mx-0 w-[calc(100%+2rem)] sm:w-full [mask-image:linear-gradient(to_right,transparent,black_16px,black_calc(100%-16px),transparent)]">
            <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar px-5 sm:px-4">
               <FilterPill active={activePlatform === "all"} onClick={() => setActivePlatform("all")}>Todas</FilterPill>
               {availablePlatforms.map(plat => {
                 let displayName = plat;
                 if (plat.toLowerCase() === "google-ai-studio" || plat.toLowerCase() === "google ai studio" || plat.toLowerCase() === "gemini") displayName = "Gemini";
                 if (plat.toLowerCase() === "chatgpt") displayName = "ChatGPT";

                 return (
                   <FilterPill key={plat} active={activePlatform === plat} onClick={() => setActivePlatform(plat)}>
                     <span className="capitalize">{displayName}</span>
                   </FilterPill>
                 );
               })}
            </div>
          </div>
        )}
      </div>

      {error ? (
        <div className="p-4 bg-red-500/10 text-red-400 rounded-2xl text-center text-sm">{error.message || "Erro ao carregar packs"}</div>
      ) : isLoading && items.length === 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Array.from({length: 4}).map((_, i) => <BaseCard.Skeleton key={i} className={i % 4 === 0 ? "md:col-span-2" : ""} />)}
        </div>
      ) : filteredPacks.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {filteredPacks.map((pack, i) => (
              <div key={pack.id} className={i % 4 === 0 ? "md:col-span-2" : ""}>
                 <PackCard pack={pack} />
              </div>
            ))}
          </div>
          <InfiniteScrollObserver hasMore={hasMore} isLoading={isLoading} onIntersect={loadMore} />
        </>
      ) : (
        <div className="px-6 py-10 text-center text-zinc-500 bg-card rounded-3xl border border-white/5 text-sm flex flex-col items-center">
          <Package className="h-8 w-8 mb-3 opacity-20" />
          Nenhum pack publicado ainda.
        </div>
      )}
    </div>
  );
}
