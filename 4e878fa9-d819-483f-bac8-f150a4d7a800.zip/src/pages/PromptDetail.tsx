import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Share2, Youtube, CheckCircle2, Maximize2, X, Terminal, Crown, Copy, Star } from "lucide-react";
import { motion } from "motion/react";
import toast from "react-hot-toast";
import { Prompt } from "@/src/types";
import { getPromptById } from "@/src/services/promptService";
import { useAuth } from "@/src/hooks/useAuth";
import { usePlus } from "@/src/hooks/usePlus";
import { Badge } from "@/src/components/ui/Badge";
import { PromptContentBlock } from "@/src/components/prompt/PromptContentBlock";
import { PlusLockCard } from "@/src/components/prompt/PlusLockCard";
import { getConfigWithFallback } from "@/src/services/configService";

export function PromptDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isPlus } = usePlus();
  
  const [prompt, setPrompt] = useState<Prompt | null>(null);
  const [loading, setLoading] = useState(true);
  const [isImageModalOpen, setImageModalOpen] = useState(false);
  const [config, setConfig] = useState<any>(null);

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      setLoading(true);
      const [p, conf] = await Promise.all([getPromptById(id), getConfigWithFallback()]);
      setConfig(conf);
      if (p) {
        setPrompt(p);
        
        // Save to recent
        const recent = JSON.parse(localStorage.getItem('promptai_recent_prompts') || '[]');
        const filtered = recent.filter((rp: any) => rp.id !== p.id);
        filtered.unshift({
          id: p.id,
          title: p.title,
          platform: p.platform,
          access: p.access,
          category: p.category,
          tested: p.tested
        });
        localStorage.setItem('promptai_recent_prompts', JSON.stringify(filtered.slice(0, 10)));
      }
      setLoading(false);
    };
    load();
  }, [id, user]);

  const share = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: prompt?.title, url }).catch(console.error);
    } else {
      navigator.clipboard.writeText(url);
      toast.success("Link copiado!");
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-white/50 animate-pulse mt-20">Carregando prompt...</div>;
  }

  if (!prompt || !prompt.active) {
    return (
      <div className="p-8 text-center text-white/50 mt-20">
        <p>Prompt não encontrado ou inativo.</p>
        <button onClick={() => navigate(-1)} className="mt-4 text-primary underline">Voltar</button>
      </div>
    );
  }

  const isLocked = prompt.access === "plus" && !isPlus;

  const handleCopy = () => {
    if (isLocked) {
      toast("Este prompt faz parte do plano Plus.", { icon: "👑" });
      navigate('/plus');
      return;
    }
    navigator.clipboard.writeText(prompt.content).then(() => {
      toast.success("Prompt copiado com sucesso");
    }).catch(() => {
      toast.error("Erro ao colar, tente selecionar o texto manualmente.");
    });
  };

  return (
    <div className="pb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-6">
        
        {/* Header Section */}
        <div>
          <div className="flex items-start gap-4 mb-4">
            {(prompt.thumbnailURL || (prompt as any).thumbnailUrl || prompt.imageURL || (prompt as any).imageUrl || prompt.coverURL) ? (
              <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0 bg-white/5 border border-white/10 shadow-lg relative">
                <img src={prompt.thumbnailURL || (prompt as any).thumbnailUrl || prompt.imageURL || (prompt as any).imageUrl || prompt.coverURL} alt={prompt.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-2xl"></div>
              </div>
            ) : (
              <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0 bg-primary/10 border border-primary/20 flex items-center justify-center shadow-lg relative">
                <Terminal className="h-8 w-8 text-primary" />
              </div>
            )}
             <div className="flex-1">
                <div className="flex flex-wrap gap-2 mb-2">
                  {prompt.access === "plus" ? <Badge variant="plus" className="text-[10px] flex items-center uppercase px-1.5 py-0 gap-0.5"><Crown className="w-2.5 h-2.5" /> Plus</Badge> : <Badge variant="outline" className="text-[10px] text-zinc-400 border-zinc-700 uppercase px-1.5 py-0">Grátis</Badge>}
                  {prompt.tested && (
                    <Badge variant="success" className="text-[10px] gap-1 px-1.5 py-0">
                      <CheckCircle2 className="h-2.5 w-2.5" /> Testado
                    </Badge>
                  )}
                  {prompt.featured && (
                    <Badge variant="default" className="text-[10px] bg-white text-black px-1.5 py-0 gap-1">
                      <Star className="w-2.5 h-2.5 fill-current" /> Destaque
                    </Badge>
                  )}
                </div>
                <h1 className="text-2xl font-bold tracking-tight leading-snug">{prompt.title}</h1>
             </div>
          </div>
          
          <p className="text-zinc-300 text-[15px] leading-relaxed mb-4">{prompt.description}</p>

          <div className="flex items-center gap-3 text-sm text-zinc-400 mb-6 flex-wrap">
            <span className="capitalize">{prompt.platform}</span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span className="capitalize">{prompt.category}</span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span className="capitalize">{prompt.level || 'Básico'}</span>
          </div>

          {prompt.suggestedBy && prompt.suggestedBy.name && (
            <div className="flex items-center gap-2 mt-4 px-3 py-2 rounded-xl bg-primary/5 border border-primary/10 w-fit">
              {prompt.suggestedBy.photoURL ? (
                <img src={prompt.suggestedBy.photoURL} alt={prompt.suggestedBy.name} className="w-5 h-5 rounded-full object-cover" />
              ) : (
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center text-primary text-[9px] font-bold">
                  {prompt.suggestedBy.name.charAt(0).toUpperCase()}
                </div>
              )}
              <span className="text-[11px] text-zinc-400 uppercase tracking-widest font-medium">
                Sugerido por <strong className="text-primary-light lowercase capitalize">{prompt.suggestedBy.name}</strong>
              </span>
            </div>
          )}
        </div>

        {/* Content Section */}
        <div className="space-y-6">
          
          {/* Locked State Container */}
          {isLocked ? (
            <div className="bg-card rounded-[2rem] border border-white/5 p-6 space-y-6">
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Prompt Estruturado</h3>
              <div className="relative overflow-hidden rounded-2xl min-h-[280px]">
                 <div className="blur-sm opacity-50 select-none pointer-events-none absolute inset-0">
                   <PromptContentBlock 
                      content={prompt.content.substring(0, 200) + "\n\n..."} 
                   />
                 </div>
                 <div className="absolute inset-0 bg-background/40 z-10 flex items-center justify-center rounded-2xl border border-white/5">
                   <div className="w-full max-w-sm px-4">
                     <PlusLockCard config={config} />
                   </div>
                 </div>
               </div>
            </div>
          ) : (
            <>
              {(prompt.usageInstructions || (prompt.editableFields && prompt.editableFields.length > 0)) && (
                <div className="bg-card rounded-[2rem] border border-white/5 p-6 space-y-6">
                  {prompt.usageInstructions && (
                    <div>
                      <h3 className="text-xs font-semibold text-primary uppercase tracking-widest pl-1 mb-3">Instruções de Uso</h3>
                      <p className="text-sm text-zinc-300 whitespace-pre-line leading-relaxed">{prompt.usageInstructions}</p>
                    </div>
                  )}

                  {prompt.editableFields && prompt.editableFields.length > 0 && (
                    <div className={prompt.usageInstructions ? "pt-6 border-t border-white/5" : ""}>
                      <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Campos Editáveis</h3>
                      <p className="text-xs text-zinc-400 mb-3 pl-1">Substitua os campos dentro do prompt com suas informações:</p>
                      <div className="flex flex-wrap gap-2">
                        {prompt.editableFields.map((field, idx) => (
                          <span key={idx} className="bg-primary/10 text-primary-light border border-primary/20 text-xs px-3 py-1.5 rounded-lg font-mono">
                            [{field}]
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="bg-card rounded-[2rem] border border-white/5 p-6 space-y-6">
                <div>
                  <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Prompt Estruturado</h3>
                  <PromptContentBlock content={prompt.content} hideCopyButton={true} />
                  
                  <button 
                    onClick={handleCopy}
                    className="w-full mt-4 bg-primary text-white hover:bg-primary-dark transition-colors py-4 rounded-2xl flex items-center justify-center gap-2 font-bold shadow-lg shadow-primary/20"
                  >
                    <Copy className="w-5 h-5" />
                    Copiar Prompt
                  </button>
                </div>

                {prompt.expectedResult && (
                  <div className="pt-6 border-t border-white/5">
                    <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Resultado Esperado</h3>
                    <div className="bg-white/5 border border-white/5 rounded-2xl p-5 text-sm text-zinc-300 italic relative">
                      <div className="absolute top-0 left-0 w-1 h-full bg-primary/50 rounded-l-2xl"></div>
                      "{prompt.expectedResult}"
                    </div>
                  </div>
                )}

                {prompt.imageURL && (
                  <div className="pt-6 border-t border-white/5">
                    <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Imagem de Exemplo</h3>
                    <div className="relative rounded-2xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setImageModalOpen(true)}>
                      <img src={prompt.imageURL} alt="Exemplo" className="w-full h-auto object-cover" />
                      <div className="absolute inset-0 bg-black/40 xl:opacity-0 xl:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4">
                        <div className="bg-black/60 backdrop-blur-md rounded-full p-3 text-white">
                          <Maximize2 className="w-5 h-5" />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                 {prompt.videoExampleURL && (
                  <div className="pt-6 border-t border-white/5">
                    <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-widest pl-1 mb-3">Exemplo em Vídeo</h3>
                    <a href={prompt.videoExampleURL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors">
                      <Youtube className="h-4 w-4" /> Assistir Exemplo no YouTube
                    </a>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

      </div>

      {isImageModalOpen && prompt.imageURL && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4" onClick={() => setImageModalOpen(false)}>
           <button className="absolute top-4 right-4 text-white hover:bg-white/10 rounded-full p-2" onClick={(e) => { e.stopPropagation(); setImageModalOpen(false); }}>
             <X className="w-6 h-6" />
           </button>
           <img src={prompt.imageURL} alt="Exemplo Completo" className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}
