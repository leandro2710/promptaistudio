/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { MobileLayout } from "./components/layout/MobileLayout";
import { AppSplashScreen } from "./components/layout/AppSplashScreen";
import { AnimatePresence } from "motion/react";
import React, { useState, useEffect, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// Lazy routes
const Home = React.lazy(() => import("./pages/Home").then(m => ({ default: m.Home })));
const Prompts = React.lazy(() => import("./pages/Prompts").then(m => ({ default: m.Prompts })));
const Categories = React.lazy(() => import("./pages/Categories").then(m => ({ default: m.Categories })));
const CategoryDetail = React.lazy(() => import("./pages/CategoryDetail").then(m => ({ default: m.CategoryDetail })));
const PromptDetail = React.lazy(() => import("./pages/PromptDetail").then(m => ({ default: m.PromptDetail })));
const Packs = React.lazy(() => import("./pages/Packs").then(m => ({ default: m.Packs })));
const PackDetail = React.lazy(() => import("./pages/PackDetail").then(m => ({ default: m.PackDetail })));
const Updates = React.lazy(() => import("./pages/Updates").then(m => ({ default: m.Updates })));
const Plus = React.lazy(() => import("./pages/Plus").then(m => ({ default: m.Plus })));
const Settings = React.lazy(() => import("./pages/Settings").then(m => ({ default: m.Settings })));
const Profile = React.lazy(() => import("./pages/Profile").then(m => ({ default: m.Profile })));
const About = React.lazy(() => import("./pages/About").then(m => ({ default: m.About })));
const Login = React.lazy(() => import("./pages/Login").then(m => ({ default: m.Login })));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
});

const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

const SplashManager = ({ children }: { children: React.ReactNode }) => {
  const { loading: authLoading } = useAuth();
  const [minSplashDone, setMinSplashDone] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setMinSplashDone(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const showSplash = !minSplashDone || authLoading;

  return (
    <>
      <AnimatePresence>
        {showSplash && <AppSplashScreen />}
      </AnimatePresence>
      <div className={showSplash ? "opacity-0 pointer-events-none hidden" : "opacity-100 flex-1 relative h-full w-full"}>
        {!showSplash && children}
      </div>
    </>
  );
};

// Root Route handler to check onboarding
const RootRedirect = () => {
  return <Navigate to="/home" replace />;
};

import { useAppearance } from "./hooks/useAppearance";

export default function App() {
  useAppearance();

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <SplashManager>
          <BrowserRouter>
            <Suspense fallback={<AppSplashScreen visible={true} />}>
              <Routes>
                <Route path="/login" element={<Login />} />
                
                {/* Main App Layout */}
                <Route element={<AuthGuard><MobileLayout /></AuthGuard>}>
                  <Route path="/" element={<RootRedirect />} />
                  <Route path="/home" element={<Home />} />
                  <Route path="/prompts" element={<Prompts />} />
                  <Route path="/explore" element={<Navigate to="/prompts" replace />} />
                  <Route path="/categories" element={<Categories />} />
                  <Route path="/category/:slug" element={<CategoryDetail />} />
                  <Route path="/prompt/:id" element={<PromptDetail />} />
                  <Route path="/packs" element={<Packs />} />
                  <Route path="/pack/:id" element={<PackDetail />} />
                  <Route path="/updates" element={<Updates />} />
                  <Route path="/plus" element={<Plus />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/about" element={<About />} />
                </Route>
              </Routes>
            </Suspense>
          </BrowserRouter>
          <Toaster 
            position="top-center" 
            toastOptions={{ 
              style: { background: '#1c1c28', color: '#fff', borderRadius: '1rem', border: '1px solid rgba(255,255,255,0.1)' }
            }} 
          />
        </SplashManager>
      </AuthProvider>
    </QueryClientProvider>
  );
}