import { Link } from "react-router-dom";
import { Category } from "@/src/types";
import { GlassCard } from "../ui/GlassCard";

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link to={"/category/" + category.slug} className="block">
      <GlassCard className="flex items-center gap-4 hover:bg-card-hover transition-colors p-4">
        <div 
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-2xl"
          style={{ backgroundColor: category.color + "20", color: category.color }}
        >
          {/* using emoji or text icon as fallback since we don't have dynamic icon components easily mapable without setup */}
          <span className="text-xl">{category.icon}</span>
        </div>
        <div className="flex-1 overflow-hidden">
          <h3 className="font-semibold text-white truncate">{category.name}</h3>
        </div>
      </GlassCard>
    </Link>
  );
}
