import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { Header } from "./Header";
import { BottomNav } from "./BottomNav";
import { PushNotificationManager } from "../PushNotificationManager";
import { ErrorBoundary } from "./ErrorBoundary";

export function MobileLayout() {
  const location = useLocation();
  const navigate = useNavigate();

  const mainRoutes = ['/home', '/prompts', '/packs', '/settings'];
  const isMainRoute = mainRoutes.includes(location.pathname);

  return (
    <div className="flex h-[100dvh] w-full flex-col overflow-hidden bg-background relative">
      <PushNotificationManager />
      <Header isMainRoute={isMainRoute} />
      <main 
        className="flex-1 overflow-y-auto px-4 sm:px-6 relative scroll-smooth"
        style={{ paddingBottom: isMainRoute ? 'calc(env(safe-area-inset-bottom) + 140px)' : 'calc(env(safe-area-inset-bottom) + 24px)' }}
      >
        <div className="w-full min-h-full py-4">
          <ErrorBoundary>
            <Outlet />
          </ErrorBoundary>
        </div>
      </main>
      {isMainRoute && (
        <div className="absolute bottom-0 w-full z-50 bottom-nav-wrapper pointer-events-none">
          <div className="pointer-events-auto">
            <BottomNav />
          </div>
        </div>
      )}
    </div>
  );
}
