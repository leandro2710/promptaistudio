import { Link, useNavigate } from "react-router-dom";
import { User, Bell, Crown, ArrowLeft } from "lucide-react";
import { useAuth } from "@/src/hooks/useAuth";
import { usePlus } from "@/src/hooks/usePlus";
import { Badge } from "../ui/Badge";
import { PromptAILogo } from "@/src/components/brand/PromptAILogo";

interface HeaderProps {
  isMainRoute?: boolean;
}

export function Header({ isMainRoute = true }: HeaderProps) {
  const { user } = useAuth();
  const { isPlus } = usePlus();
  const navigate = useNavigate();

  return (
    <header className="flex h-16 shrink-0 items-center justify-between px-4 sm:px-6 border-b border-white/5 bg-background/80 backdrop-blur-md z-[60] relative">
      <div className="flex items-center gap-3">
        {!isMainRoute && (
          <button 
            onClick={() => {
              if (window.history.length > 1) {
                navigate(-1);
              } else {
                navigate('/home');
              }
            }} 
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/5 hover:bg-white/10 transition-colors border border-white/10 shadow-sm"
          >
            <ArrowLeft className="h-5 w-5 text-white" />
          </button>
        )}
        <div className="group flex items-center gap-3 cursor-pointer" onClick={() => navigate('/home')}>
          {isMainRoute && <PromptAILogo size={36} variant="glow" />}
          <div className="flex flex-col">
            <span className="text-sm font-medium text-white/50">
              {user ? "Olá, " + user.name.split(' ')[0] + " 👋" : "Bem-vindo 👋"}
            </span>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight group-hover:text-primary transition-colors">PromptAI Studio</span>
              {isPlus && <Badge variant="plus" className="text-[9px] uppercase px-1.5 py-0 flex items-center gap-0.5"><Crown className="w-2.5 h-2.5" /> Plus</Badge>}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-3">
        <Link to="/profile" className="flex h-10 w-10 items-center justify-center rounded-full bg-card hover:bg-card-hover transition-colors overflow-hidden border border-white/5">
          {user?.photoURL ? (
            <img src={user.photoURL} alt={user.name} className="h-full w-full object-cover" />
          ) : (
            <User className="h-5 w-5 text-white/70" />
          )}
        </Link>
      </div>
    </header>
  );
}
