import { Home, Package, Settings, TerminalSquare } from "lucide-react";
import { NavLink } from "react-router-dom";
import { cn } from "@/src/lib/utils";

const items = [
  { path: "/home", label: "Início", icon: Home },
  { path: "/prompts", label: "Prompts", icon: TerminalSquare },
  { path: "/packs", label: "Packs", icon: Package },
  { path: "/settings", label: "Ajustes", icon: Settings },
];

export function BottomNav() {
  return (
    <div className="absolute bottom-6 left-6 right-6 z-50">
      <nav className="relative mx-auto max-w-lg rounded-[28px] border border-white/10 bg-black/30 pb-[env(safe-area-inset-bottom)] backdrop-blur-[40px] shadow-[0_8px_32px_rgba(0,0,0,0.6)] overflow-hidden">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-50" />
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[var(--logo-surface-from,rgba(124,58,237,0.1))] to-transparent opacity-50 pointer-events-none" />
        <div className="relative flex h-16 items-center justify-between px-6 z-10">
          {items.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center gap-1 min-w-[56px]",
                  isActive ? "text-primary" : "text-white/40 hover:text-white/70"
                )
              }
            >
              {({ isActive }) => (
                <>
                  <div className={cn("relative flex h-8 w-8 items-center justify-center rounded-xl transition-all duration-300", isActive && "bg-[#ffffff0a] shadow-[inset_0_1px_1px_rgba(255,255,255,0.1)]")}>
                    <Icon className="h-5 w-5" strokeWidth={isActive ? 2.5 : 2} />
                  </div>
                  <span className={cn("text-[10px] font-medium transition-colors", isActive ? "text-white" : "text-white/50")}>{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </div>
      </nav>
    </div>
  );
}
