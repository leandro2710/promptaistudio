import { motion } from "motion/react";
import { PromptAILogo } from "@/src/components/brand/PromptAILogo";
import { Z } from "@/src/lib/z-index";
import { cn } from "@/src/lib/utils";

type AppSplashScreenProps = {
  visible?: boolean;
};

export function AppSplashScreen({ visible = true }: AppSplashScreenProps) {
  if (!visible) return null;

  return (
    <div className={cn("fixed inset-0 flex items-center justify-center overflow-hidden bg-[#000000] px-6", `z-[${Z.modal}]`)}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,var(--logo-surface-from,rgba(124,58,237,0.20)),transparent_42%)]" />
      <div className="absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-[var(--logo-primary,#7c3aed)]/20 blur-[90px]" />
      <div className="absolute bottom-0 right-0 h-64 w-64 rounded-full bg-[var(--logo-primary,#7c3aed)]/10 blur-[90px]" />

      <motion.div
        initial={{ opacity: 0, y: 18, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        transition={{ duration: 0.65, ease: "easeOut" }}
        className={cn("relative flex w-full max-w-[360px] flex-col items-center text-center", `z-[${Z.cardOverlay}]`)}
      >
        <motion.div
          initial={{ scale: 0.9, rotate: -4 }}
          animate={{
            scale: [1, 1.035, 1],
            rotate: [0, 1.5, 0],
          }}
          transition={{
            duration: 2.4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="mb-6 flex h-28 w-28 items-center justify-center drop-shadow-[0_0_45px_var(--logo-glow,rgba(124,58,237,0.22))]"
        >
          <PromptAILogo size={92} variant="glow" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.16, duration: 0.5 }}
          className="text-3xl font-black tracking-tight text-white mt-4"
        >
          PromptAI Studio
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.28, duration: 0.5 }}
          className="mt-3 max-w-[310px] text-[15px] leading-relaxed text-white/50"
        >
          O seu estúdio de prompts para Inteligência Artificial.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.42, duration: 0.5 }}
          className="mt-12 flex flex-col items-center gap-4"
        >
          <div className="relative flex items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-white/10 border-t-primary" style={{ borderTopColor: 'var(--logo-primary, #a855f7)' }} />
          </div>

          <p className="text-[10px] font-semibold tracking-[0.2em] text-white/30 uppercase mt-2">
            Preparando SUA EXPERIÊNCIA
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}

export default AppSplashScreen;
