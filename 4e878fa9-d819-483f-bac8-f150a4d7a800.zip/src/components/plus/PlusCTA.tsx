import { MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "../ui/Button";
import { cn } from "@/src/lib/utils";
import { Crown } from "lucide-react";

interface PlusCTAProps {
  className?: string;
  price?: string;
}

export function PlusCTA({ className, price }: PlusCTAProps) {
  return (
    <div className={cn("rounded-3xl bg-gradient-to-br from-yellow-500/20 to-yellow-700/5 p-5 border border-yellow-500/20 relative overflow-hidden", className)}>
      <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/20 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>
      
      <div className="flex gap-4 items-start relative z-10">
        <div className="flex bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl h-12 w-12 items-center justify-center shrink-0 shadow-[0_0_15px_rgba(234,179,8,0.3)] border border-yellow-400/50">
          <Crown className="h-6 w-6 text-yellow-950 drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" />
        </div>
        
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <h3 className="text-lg font-bold text-yellow-400 leading-tight mb-1">
            Desbloqueie o Plus
          </h3>
          <p className="text-sm text-zinc-300 leading-relaxed mb-4">
            Tenha acesso a prompts exclusivos, geração de imagens e ferramentas avançadas de inteligência artificial.
          </p>
          
          <div className="flex items-center justify-between mt-auto">
            <span className="font-bold text-lg text-yellow-400">
              {price || "Assine Agora"}
            </span>
            <Link to="/plus">
               <Button variant="plus" size="sm" className="rounded-full shadow-lg px-4 h-9 gap-1.5 font-bold whitespace-nowrap">
                 Desbloquear
               </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
