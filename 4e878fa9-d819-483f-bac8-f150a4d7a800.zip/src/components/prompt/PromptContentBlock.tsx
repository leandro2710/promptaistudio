import { Copy, Check } from "lucide-react";
import { useState } from "react";
import toast from "react-hot-toast";
import { cn } from "@/src/lib/utils";

interface PromptContentBlockProps {
  content: string;
  className?: string;
  hideCopyButton?: boolean;
}

export function PromptContentBlock({ content, className, hideCopyButton = false }: PromptContentBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      toast.success("Prompt copiado com sucesso");
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error("Failed to copy", err);
      toast.error("Erro ao copiar, selecione manualmente.");
    });
  };

  return (
    <div className={cn("relative group rounded-2xl border border-white/10 bg-black/50 overflow-hidden", className)}>
      {!hideCopyButton && (
        <div className="absolute top-2 right-2 z-10">
          <button
            onClick={handleCopy}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-card border border-white/10 text-white/70 hover:text-white hover:bg-card-hover transition-colors"
            title="Copiar prompt"
          >
            {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
          </button>
        </div>
      )}
      <div className={cn("p-4 text-sm text-zinc-300 font-mono whitespace-pre-wrap select-auto max-h-[60vh] overflow-y-auto custom-scrollbar leading-relaxed", !hideCopyButton ? "pt-12" : "")}>
        {content}
      </div>
    </div>
  );
}
