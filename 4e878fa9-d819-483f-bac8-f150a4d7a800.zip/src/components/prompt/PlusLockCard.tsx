import { Lock, MessageCircle } from "lucide-react";
import { Button } from "../ui/Button";
import { AppConfig } from "@/src/types";
import { Crown } from "lucide-react";

interface PlusLockCardProps {
  config: AppConfig | null;
}

export function PlusLockCard({ config }: PlusLockCardProps) {
  const handleWhatsApp = () => {
    if (config?.whatsappNumber) {
      const msg = encodeURIComponent(config.whatsappMessage || 'Olá, quero assinar o Plus.');
      window.open("https://wa.me/" + config.whatsappNumber + "?text=" + msg, '_blank');
    }
  };

  return (
    <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-card to-background p-6 text-center shadow-xl">
      <div className="absolute inset-0 bg-primary/5 blur-3xl" />
      <div className="relative z-10 flex flex-col items-center justify-center space-y-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-yellow-500 to-yellow-300 shadow-lg border border-yellow-400/50">
          <Lock className="h-6 w-6 text-yellow-950" />
        </div>
        
        <div>
          <h3 className="text-xl font-bold tracking-tight mb-1 flex items-center justify-center gap-2">
            Desbloqueie o Plus <Crown className="h-5 w-5" />
          </h3>
          <p className="text-sm text-zinc-400 max-w-[280px] mx-auto">
            Este conteúdo é exclusivo para assinantes PromptAI Plus. Tenha acesso a packs plus e prompts avançados.
          </p>
        </div>

        <Button onClick={handleWhatsApp} variant="plus" className="w-full mt-4 gap-2">
          <MessageCircle className="h-5 w-5" /> Liberar no WhatsApp
        </Button>
      </div>
    </div>
  );
}
