import { Prompt } from "@/src/types";
import { BaseCard } from "../ui/BaseCard";

interface PromptCardProps {
  prompt: Prompt;
}

export function PromptCard({ prompt }: PromptCardProps) {
  const isNew = prompt.createdAt && (Date.now() - prompt.createdAt.toMillis() < 7 * 24 * 60 * 60 * 1000);

  return (
    <BaseCard
      id={prompt.id || ""}
      variant="prompt"
      title={prompt.title}
      description={prompt.description}
      href={"/prompt/" + prompt.id}
      thumbnailUrl={prompt.thumbnailURL || (prompt as any).thumbnailUrl || prompt.imageURL || (prompt as any).imageUrl || prompt.coverURL || (prompt as any).coverUrl}
      isPlus={prompt.access === "plus"}
      isNew={!!isNew}
      isFeatured={prompt.featured}
      isTested={prompt.tested}
      platform={prompt.platform}
      category={prompt.category}
      level={prompt.level}
    />
  );
}
