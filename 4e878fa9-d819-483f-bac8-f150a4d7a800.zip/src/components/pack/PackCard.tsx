import { Pack } from "@/src/types";
import { BaseCard } from "../ui/BaseCard";

interface PackCardProps {
  pack: Pack;
}

export function PackCard({ pack }: PackCardProps) {
  const isNew = pack.createdAt && (Date.now() - pack.createdAt.toMillis() < 7 * 24 * 60 * 60 * 1000);

  return (
    <BaseCard
      id={pack.id || ""}
      variant="pack"
      title={pack.title}
      description={pack.description}
      href={"/pack/" + pack.id}
      thumbnailUrl={pack.thumbnailURL || (pack as any).thumbnailUrl || pack.imageURL || (pack as any).imageUrl || pack.coverURL}
      isPlus={pack.access === "plus"}
      isNew={!!isNew}
      isFeatured={pack.featured}
      platform={(pack as any).platform}
      category={pack.category}
      promptCount={pack.promptIds?.length || 0}
    />
  );
}
