import { useId } from "react";

type PromptAILogoProps = {
  size?: number | string;
  className?: string;
  title?: string;
  variant?: "default" | "flat" | "glow";
};

export function PromptAILogo({
  size = 40,
  className = "",
  title = "PromptAI Studio",
  variant = "glow",
}: PromptAILogoProps) {
  const rawId = useId().replace(/:/g, "");
  const gradientId = `${rawId}-promptai-grad`;
  const surfaceGradientId = `${rawId}-promptai-surf`;
  const glowId = `${rawId}-promptai-glow`;
  const shadowId = `${rawId}-promptai-shadow`;

  const useGlow = variant === "glow";
  const useFlat = variant === "flat";

  // Retangular mas muito elegante e perfeitamente equilibrado
  const bubblePath = "M 72 32 H 184 C 206.09 32 224 49.91 224 72 V 144 C 224 166.09 206.09 184 184 184 H 128 L 89.6 212.8 C 83.2 217.6 74 213.03 74 205.03 V 184 H 72 C 49.91 184 32 166.09 32 144 V 72 C 32 49.91 49.91 32 72 32 Z";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 256 256"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
      className={`promptai-logo ${className} transition-all duration-300`}
      style={{
        color: "var(--logo-primary, #ffffff)",
      }}
    >
      <title>{title}</title>

      <defs>
        <linearGradient
          id={gradientId}
          x1="32" y1="32" x2="224" y2="224"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="var(--logo-gradient-from, #ffffff)" />
          <stop offset="50%" stopColor="var(--logo-gradient-mid, var(--logo-primary, #ffffff))" />
          <stop offset="100%" stopColor="var(--logo-gradient-to, #d1d5db)" />
        </linearGradient>

        <linearGradient
          id={surfaceGradientId}
          x1="32" y1="32" x2="224" y2="224"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="var(--logo-surface-from, rgba(255,255,255,0.12))" />
          <stop offset="50%" stopColor="var(--logo-surface-mid, rgba(255,255,255,0.04))" />
          <stop offset="100%" stopColor="var(--logo-surface-to, rgba(255,255,255,0.08))" />
        </linearGradient>

        <filter id={glowId} x="-30%" y="-30%" width="160%" height="160%" colorInterpolationFilters="sRGB">
          <feDropShadow dx="0" dy="0" stdDeviation={useGlow ? "5" : "0"} floodColor="var(--logo-glow, var(--logo-primary, #ffffff))" floodOpacity={useGlow ? "0.4" : "0"} />
          <feDropShadow dx="0" dy="0" stdDeviation={useGlow ? "14" : "0"} floodColor="var(--logo-glow, var(--logo-primary, #ffffff))" floodOpacity={useGlow ? "0.25" : "0"} />
        </filter>

        <filter id={shadowId} x="-20%" y="-20%" width="140%" height="140%" colorInterpolationFilters="sRGB">
          <feDropShadow dx="0" dy="2" stdDeviation={useFlat ? "0" : "3"} floodColor="#000000" floodOpacity={useFlat ? "0" : "0.3"} />
        </filter>
      </defs>

      {/* Surface */}
      <path d={bubblePath} fill={`url(#${surfaceGradientId})`} />

      {/* Main bubble outline */}
      <path
        d={bubblePath}
        stroke={`url(#${gradientId})`}
        strokeWidth="12"
        strokeLinejoin="round"
        filter={useFlat ? undefined : `url(#${glowId})`}
      />

      {/* Prompt chevron */}
      <path
        d="M 62 102 L 90 126 L 62 150"
        stroke="var(--logo-symbol, #ffffff)"
        strokeWidth="12"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter={useFlat ? undefined : `url(#${shadowId})`}
      />

      {/* Prompt underscore */}
      <path
        d="M 106 150 H 142"
        stroke="var(--logo-symbol, #ffffff)"
        strokeWidth="12"
        strokeLinecap="round"
        filter={useFlat ? undefined : `url(#${shadowId})`}
      />

      {/* AI sparkles filled */}
      <g filter={useFlat ? undefined : `url(#${glowId})`}>
        {/* Main Sparkle */}
        <path
          d="M 154 64 A 28 28 0 0 0 182 92 A 28 28 0 0 0 154 120 A 28 28 0 0 0 126 92 A 28 28 0 0 0 154 64 Z"
          fill={`url(#${gradientId})`}
        />
        {/* Small Sparkle 1 */}
        <path
          d="M 122 56 A 12 12 0 0 0 134 68 A 12 12 0 0 0 122 80 A 12 12 0 0 0 110 68 A 12 12 0 0 0 122 56 Z"
          fill={`url(#${gradientId})`}
        />
        {/* Small Sparkle 2 */}
        <path
          d="M 186 112 A 8 8 0 0 0 194 120 A 8 8 0 0 0 186 128 A 8 8 0 0 0 178 120 A 8 8 0 0 0 186 112 Z"
          fill={`url(#${gradientId})`}
        />
      </g>
    </svg>
  );
}

export default PromptAILogo;
