import * as React from "react"
import { cn } from "@/src/lib/utils"

export const GlassCard = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "rounded-3xl border border-white/5 bg-card/80 backdrop-blur-xl p-5 shadow-sm overflow-clip",
      className
    )}
    {...props}
  />
))
GlassCard.displayName = "GlassCard"
