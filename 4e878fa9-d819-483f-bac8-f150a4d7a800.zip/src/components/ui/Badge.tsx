import * as React from "react"
import { cn } from "@/src/lib/utils"

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "secondary" | "outline" | "plus" | "success" | "warning"
}

export function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        {
          "bg-primary text-white": variant === "default",
          "bg-white/10 text-white": variant === "secondary",
          "border border-white/10 text-white": variant === "outline",
          "bg-gradient-to-r from-yellow-500 to-yellow-300 text-yellow-950 shadow-sm border border-yellow-400/50": variant === "plus",
          "bg-green-500/20 text-green-400": variant === "success",
          "bg-yellow-500/20 text-yellow-400": variant === "warning",
        },
        className
      )}
      {...props}
    />
  )
}
