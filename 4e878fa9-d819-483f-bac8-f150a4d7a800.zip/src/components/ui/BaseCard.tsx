import { Link } from "react-router-dom";
import { Lock, CheckCircle2, Star, Crown, Terminal, Package } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { GlassCard } from "./GlassCard";
import { Badge } from "./Badge";

export interface BaseCardProps {
  id: string;
  variant: "prompt" | "pack";
  title: string;
  description: string;
  href: string;
  thumbnailUrl?: string;
  isPlus: boolean;
  isNew: boolean;
  isFeatured?: boolean;
  isTested?: boolean;
  className?: string;
  // Specific metadata
  platform?: string;
  category?: string;
  level?: string;
  promptCount?: number;
}

export function BaseCard({
  variant,
  title,
  description,
  href,
  thumbnailUrl,
  isPlus,
  isNew,
  isFeatured,
  isTested,
  platform = "Geral",
  category = "Geral",
  level,
  promptCount,
  className
}: BaseCardProps) {
  return (
    <Link to={href} className={cn("block group h-full", className)}>
      <GlassCard 
        className={cn(
          "relative overflow-hidden transition-all duration-300 h-full",
          // Glassmorphism refinements
          "shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]",
          "before:absolute before:inset-0 before:opacity-0 hover:before:opacity-100 before:transition-opacity before:pointer-events-none before:bg-[radial-gradient(circle_at_50%_0%,_rgba(255,255,255,0.05),_transparent_70%)]",
          isPlus 
            ? "border-yellow-500/30 bg-gradient-to-br from-yellow-500/10 to-transparent hover:border-yellow-500/50 hover:bg-yellow-500/5" 
            : "border-white/5 bg-card hover:bg-card-hover hover:border-white/10"
        )}
      >
        <div className="flex gap-3 items-start relative z-10">
          {thumbnailUrl ? (
            <div className="w-10 h-10 mt-1 rounded-full overflow-hidden shrink-0 bg-white/5 border border-white/10 shadow-sm relative group-hover:border-primary/30 transition-colors">
              <img src={thumbnailUrl} alt={title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-full pointer-events-none"></div>
            </div>
          ) : (
            <div className="w-10 h-10 mt-1 rounded-full overflow-hidden shrink-0 bg-primary/10 border border-primary/20 flex items-center justify-center shadow-sm relative group-hover:border-primary/40 transition-colors">
              {variant === "prompt" ? <Terminal className="h-5 w-5 text-primary" /> : <Package className="h-5 w-5 text-primary" />}
            </div>
          )}
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className={cn("text-[15px] font-semibold leading-tight line-clamp-2 transition-colors", isPlus && "text-yellow-400 group-hover:text-yellow-300")}>
                {title}
              </h3>
              <div className="flex shrink-0 gap-1.5 flex-col items-end">
                {isPlus ? (
                  <Badge variant="plus" className="text-[9px] flex items-center gap-0.5 uppercase px-1.5 py-0">
                    <Crown className="w-2.5 h-2.5" />
                    Plus
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-[9px] text-zinc-400 border-zinc-700 uppercase px-1.5 py-0">
                    Grátis
                  </Badge>
                )}
              </div>
            </div>

            <p className="text-xs text-zinc-400 line-clamp-2 mb-3 leading-relaxed">
              {description}
            </p>

            <div className="flex flex-wrap items-center gap-1.5">
              {isFeatured && (
                <Badge variant="default" className="text-[9px] bg-white text-black px-1.5 py-0 gap-1">
                 <Star className="w-2 h-2 fill-current" /> Destaque
                </Badge>
              )}
              {isNew && (
                <Badge variant="default" className="text-[9px] bg-primary text-white border-primary-light px-1.5 py-0">
                  Novo
                </Badge>
              )}
              {variant === "prompt" && isTested && (
                <Badge variant="success" className="text-[9px] gap-1 px-1.5 py-0">
                  <CheckCircle2 className="h-2.5 w-2.5" /> Testado
                </Badge>
              )}
              <span className="text-[10px] text-zinc-500 capitalize ml-auto truncate">
                {variant === "prompt" ? (
                  <>{platform} • {category} • {level || "Básico"}</>
                ) : (
                  <>{platform} • {category} • {promptCount || 0} prompts</>
                )}
              </span>
            </div>
          </div>
        </div>

        {isPlus && (
          <div className="absolute top-0 right-0 h-24 w-24 bg-yellow-500/20 opacity-40 blur-[40px] pointer-events-none transition-opacity group-hover:opacity-60" />
        )}
      </GlassCard>
    </Link>
  );
}

BaseCard.Skeleton = function BaseCardSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn("animate-pulse bg-white/10 rounded-2xl p-4 h-full shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]", className)}>
      <div className="flex gap-3 items-start">
        <div className="w-10 h-10 rounded-full bg-white/10 shrink-0"></div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-2 gap-2">
            <div className="space-y-2 flex-1">
              <div className="h-4 bg-white/10 rounded w-3/4"></div>
              <div className="h-4 bg-white/10 rounded w-1/2"></div>
            </div>
            <div className="h-4 w-12 bg-white/10 rounded shrink-0"></div>
          </div>
          <div className="space-y-1.5 mb-4">
            <div className="h-3 bg-white/5 rounded w-full"></div>
            <div className="h-3 bg-white/5 rounded w-full"></div>
          </div>
          <div className="flex gap-2 items-center">
            <div className="h-4 w-14 bg-white/10 rounded"></div>
            <div className="h-4 w-10 bg-white/10 rounded"></div>
            <div className="h-3 w-20 bg-white/5 rounded ml-auto"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
