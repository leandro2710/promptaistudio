import * as React from "react"
import { cn } from "@/src/lib/utils"

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline" | "ghost" | "plus" | "secondary"
  size?: "default" | "sm" | "lg" | "icon"
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", asChild = false, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-2xl text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
          {
            "bg-primary text-white hover:bg-primary/90": variant === "default",
            "bg-card text-white hover:bg-card-hover border border-white/10": variant === "secondary",
            "border border-white/10 bg-transparent hover:bg-white/5": variant === "outline",
            "hover:bg-white/10 text-white": variant === "ghost",
            "bg-gradient-to-r from-yellow-500 to-yellow-300 text-yellow-950 font-semibold shadow-lg shadow-yellow-500/20": variant === "plus",
            "h-12 px-6 py-2": size === "default",
            "h-9 rounded-xl px-3": size === "sm",
            "h-14 rounded-3xl px-8 text-base": size === "lg",
            "h-12 w-12": size === "icon",
          },
          className
        )}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }
