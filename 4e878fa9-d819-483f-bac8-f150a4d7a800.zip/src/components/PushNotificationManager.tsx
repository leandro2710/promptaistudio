import { useEffect, useRef } from "react";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { useAuth } from "@/src/hooks/useAuth";
import { Update } from "@/src/types";

export function PushNotificationManager() {
  const { user } = useAuth();
  const isInitialLoad = useRef(true);

  useEffect(() => {
    if (!user) return;

    // Request notification permission if not yet requested
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }

    const q = query(
      collection(db, "updates"),
      where("active", "==", true)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (isInitialLoad.current) {
        // Build initial local store of known update IDs
        const knownIds = JSON.parse(localStorage.getItem("promptai_known_update_ids") || "[]");
        let hasChanges = false;
        
        snapshot.docs.forEach(doc => {
          if (!knownIds.includes(doc.id)) {
            knownIds.push(doc.id);
            hasChanges = true;
          }
        });

        if (hasChanges) {
          localStorage.setItem("promptai_known_update_ids", JSON.stringify(knownIds));
        }

        isInitialLoad.current = false;
        return;
      }

      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const update = { id: change.doc.id, ...change.doc.data() } as Update;
          
          const knownIds = JSON.parse(localStorage.getItem("promptai_known_update_ids") || "[]");
          if (!knownIds.includes(update.id)) {
            // New update that we haven't seen!
            if ("Notification" in window && Notification.permission === "granted") {
              const notification = new Notification(update.title, {
                body: update.message
              });
              
              notification.onclick = () => {
                window.focus();
                // We're inside an SPA, so ideally this would navigate, 
                // but window.focus() and closing notification is a good start
                notification.close();
              };
            }

            knownIds.push(update.id);
            localStorage.setItem("promptai_known_update_ids", JSON.stringify(knownIds));
          }
        }
      });
    }, (error) => {
       console.warn("Notification Listener Error:", error);
    });

    return () => unsubscribe();
  }, [user]);

  return null;
}
