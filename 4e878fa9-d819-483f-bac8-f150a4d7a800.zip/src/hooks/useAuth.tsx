import { useState, useEffect, createContext, useContext } from 'react';
import { User as FirebaseUser, onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/src/lib/firebase';
import { getCurrentUserDoc } from '@/src/services/userService';
import { User, Role, Status } from '@/src/types';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  firebaseUser: null,
  loading: true,
  refreshUser: async () => {},
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    const currentFbUser = auth.currentUser || firebaseUser;
    if (!currentFbUser) {
      setUser(null);
      return;
    }
    try {
      const userDoc = await getCurrentUserDoc(currentFbUser.uid);
      if (userDoc) {
        setUser(userDoc);
        if (userDoc.status === 'blocked') {
          toast.error('Sua conta está bloqueada.');
        }
      }
    } catch (error) {
      console.error("Error fetching user doc:", error);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        try {
          const userDoc = await getCurrentUserDoc(fbUser.uid);
          setUser(userDoc);
        } catch (error) {
          console.error("Failed to load user profile", error);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, firebaseUser, loading, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
