import { useState, useEffect } from 'react';

export type ThemeType = 'purple' | 'blue' | 'green' | 'red' | 'orange' | 'pink' | 'gold' | 'silver' | 'diamante';
export type FontSizeType = 'small' | 'normal' | 'large';

export function useAppearance() {
  const [theme, setTheme] = useState<ThemeType>((localStorage.getItem('promptai_theme') as ThemeType) || 'purple');
  const [fontSize, setFontSize] = useState<FontSizeType>((localStorage.getItem('promptai_font_size') as FontSizeType) || 'normal');

  useEffect(() => {
    localStorage.setItem('promptai_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('promptai_font_size', fontSize);
    if (fontSize === 'small') document.documentElement.style.fontSize = '12px';
    else if (fontSize === 'large') document.documentElement.style.fontSize = '16px';
    else document.documentElement.style.fontSize = '14px';
  }, [fontSize]);

  return {
    theme, setTheme,
    fontSize, setFontSize
  };
}
