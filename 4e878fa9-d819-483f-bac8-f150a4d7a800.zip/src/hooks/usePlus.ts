import { useAuth } from './useAuth';

export const usePlus = () => {
  const { user, loading } = useAuth();
  
  if (loading) return { isPlus: false, isLoading: true, userRole: 'user', status: 'active' };
  if (!user) return { isPlus: false, isLoading: false, userRole: 'user', status: 'active' };
  if (user.status === 'blocked') return { isPlus: false, isLoading: false, userRole: user.role, status: user.status };
  
  let hasValidPlus = user.isPlus;
  
  if (hasValidPlus && user.plusUntil) {
    const defaultDate = new Date();
    // Assuming plusUntil is a Firestore Timestamp
    const expirationDate = typeof user.plusUntil.toDate === 'function' 
      ? user.plusUntil.toDate() 
      : new Date((user.plusUntil as any).seconds * 1000);
      
    if (expirationDate < defaultDate) {
      hasValidPlus = false; // Expired
    }
  }
  
  // Note: App Admin logic is also relevant. If role === 'admin' they might have access,
  // but we specifically check isPlus as requested or we can let admins bypass.
  // The firestore rules allow isAdmin() to read plus content anyway.
  if (user.role === 'admin') {
    hasValidPlus = true;
  }
  
  return {
    isPlus: hasValidPlus,
    isLoading: false,
    userRole: user.role,
    status: user.status
  };
};
