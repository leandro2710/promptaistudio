import { useState, useRef, useEffect, useCallback } from 'react';
import { query, getDocs, limit, startAfter, Query, DocumentData, QuerySnapshot, DocumentSnapshot } from 'firebase/firestore';

interface PaginatedData<T> {
  items: T[];
  isLoading: boolean;
  hasMore: boolean;
  loadMore: () => Promise<void>;
  error: Error | null;
  reset: () => void;
}

export function usePaginatedCollection<T>(
  baseQuery: Query<DocumentData> | null,
  pageSize: number = 12
): PaginatedData<T> {
  const [items, setItems] = useState<T[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const lastVisibleRef = useRef<DocumentSnapshot | null>(null);

  const reset = useCallback(() => {
    setItems([]);
    lastVisibleRef.current = null;
    setHasMore(true);
    setError(null);
  }, []);

  // When base query changes, reset everything
  useEffect(() => {
    reset();
  }, [baseQuery, reset]);

  const loadMore = useCallback(async () => {
    if (!baseQuery || isLoading || !hasMore) return;

    setIsLoading(true);
    setError(null);

    try {
      let q = query(baseQuery, limit(pageSize));
      
      if (lastVisibleRef.current) {
        q = query(baseQuery, startAfter(lastVisibleRef.current), limit(pageSize));
      }

      const snapshot: QuerySnapshot<DocumentData> = await getDocs(q);
      
      if (snapshot.empty) {
        setHasMore(false);
      } else {
        lastVisibleRef.current = snapshot.docs[snapshot.docs.length - 1];
        
        const newItems = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
        
        setItems(prev => {
          const existingIds = new Set(prev.map((i: any) => i.id));
          const filteredNew = newItems.filter((item: any) => !existingIds.has(item.id));
          return [...prev, ...filteredNew];
        });

        if (snapshot.docs.length < pageSize) {
          setHasMore(false);
        }
      }
    } catch (err: any) {
      console.error("Error loading paginated data:", err);
      setError(err);
      // Failsafe for permission/index errors: just set hasMore to false for now so it doesn't spin
      setHasMore(false);
    } finally {
      setIsLoading(false);
    }
  }, [baseQuery, isLoading, hasMore, pageSize]);

  return { items, isLoading, hasMore, loadMore, error, reset };
}
