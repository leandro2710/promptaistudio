import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { initializeFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Substitua estas chaves com as do seu projeto do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC3XpyEeRInLzHa1IQgft_pjQ7xEVTfvh0",
  authDomain: "promptai-496205.firebaseapp.com",
  projectId: "promptai-496205",
  storageBucket: "promptai-496205.firebasestorage.app",
  messagingSenderId: "228846947422",
  appId: "1:228846947422:web:2cc6e1db1b1f451f71b8cf"
};

const isConfigValid = firebaseConfig.apiKey !== "COLE_AQUI";

let app, auth, db, storage;
const googleProvider = new GoogleAuthProvider();

if (isConfigValid) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = initializeFirestore(app, { experimentalForceLongPolling: true });
  storage = getStorage(app);
} else {
  console.warn("Firebase config is missing setup. Update firebaseConfig in src/lib/firebase.ts");
}

export { app, auth, db, storage, googleProvider, signInWithPopup, signOut };
