export const Z = {
  base: 0,
  cardOverlay: 10,
  stickyHeader: 40,
  modal: 50,
  toast: 60,
};
