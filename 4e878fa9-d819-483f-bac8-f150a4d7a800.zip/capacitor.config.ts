import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.promptstudio.app',
  appName: 'PromptAI Studio',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
