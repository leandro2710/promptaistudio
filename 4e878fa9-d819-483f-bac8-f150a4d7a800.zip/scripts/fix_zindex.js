const fs = require('fs');
const glob = require('glob');

const mapping = {
  'z-10': 'z-overlay',
  'z-20': 'z-overlay',
  'z-30': 'z-header',
  'z-40': 'z-header',
  'z-50': 'z-modal',
  'z-[100]': 'z-modal',
  'z-[9999]': 'z-modal',
};

function readFiles() {
  const filePaths = glob.sync('src/**/*.{tsx,ts}', { nodir: true });
  let count = 0;
  for (const file of filePaths) {
    let code = fs.readFileSync(file, 'utf8');
    let changed = false;
    for (const [oldZ, newZ] of Object.entries(mapping)) {
      if (code.includes(oldZ)) {
        // match word bounds somewhat safely
        const regex = new RegExp(`\\b${oldZ.replace('[','\\[').replace(']', '\\]')}\\b`, 'g');
        if (code.match(regex)) {
           code = code.replace(regex, newZ);
           changed = true;
        }
      }
    }
    if (changed) {
      fs.writeFileSync(file, code, 'utf8');
      console.log('Fixed z-index in', file);
      count++;
    }
  }
  console.log('Total fixed files:', count);
}
readFiles();
