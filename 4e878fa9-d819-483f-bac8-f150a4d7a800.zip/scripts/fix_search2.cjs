const fs = require('fs');

const files = ['src/pages/Prompts.tsx', 'src/pages/Packs.tsx', 'src/pages/Favorites.tsx'];

files.forEach(file => {
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace(
    /<div className="relative z-20 w-full mt-4 mb-4">/g,
    '<div className="relative z-10 w-full mt-4 mb-4">'
  );
  code = code.replace(
    /<SearchIcon className="absolute left-4 top-1\/2 -translate-y-1\/2 h-5 w-5 text-zinc-500 pointer-events-none z-30" \/>/g,
    '<SearchIcon className="absolute left-4 top-[14px] h-5 w-5 text-zinc-500 pointer-events-none" />'
  );
  fs.writeFileSync(file, code, 'utf8');
});
console.log('Fixed search wrapper z-index again');
