const fs = require('fs');
const path = require('path');

const mapping = {
  'z-10': 'z-overlay',
  'z-20': 'z-overlay',
  'z-30': 'z-header',
  'z-40': 'z-header',
  'z-50': 'z-modal',
  'z-\\[100\\]': 'z-modal',
  'z-\\[9999\\]': 'z-modal',
};

function readDirRecursive(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(readDirRecursive(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(file);
    }
  });
  return results;
}

function readFiles() {
  const filePaths = readDirRecursive('src');
  let count = 0;
  for (const file of filePaths) {
    let code = fs.readFileSync(file, 'utf8');
    let changed = false;
    for (const [oldZ, newZ] of Object.entries(mapping)) {
      const regex = new RegExp(oldZ, 'g');
      if (code.match(regex)) {
         code = code.replace(regex, newZ);
         changed = true;
      }
    }
    if (changed) {
      fs.writeFileSync(file, code, 'utf8');
      console.log('Fixed z-index in', file);
      count++;
    }
  }
  console.log('Total fixed files:', count);
}
readFiles();
