const fs = require('fs');

const pages = [
  { file: 'src/pages/Prompts.tsx', placeholder: 'Buscar...' },
  { file: 'src/pages/Packs.tsx', placeholder: 'Buscar packs...' },
  { file: 'src/pages/Favorites.tsx', placeholder: 'Buscar nos favoritos...' }
];

pages.forEach(({ file, placeholder }) => {
  let content = fs.readFileSync(file, 'utf8');

  const altRegex = new RegExp(
      `<div className="relative z-10 w-full mt-4 mb-4">([\\s\\S]*?)<\\/div>`
  );
  
  content = content.replace(altRegex, (match, inner) => {
      return `<div className="relative z-[20] w-full mt-4 mb-4">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-[30]" />
        <input 
          type="text" 
          placeholder="${placeholder}" 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="relative z-[10] w-full h-12 bg-card border border-white/5 rounded-2xl pl-12 pr-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-primary/50"
        />
      </div>`;
  });

  fs.writeFileSync(file, content, 'utf8');
});

console.log('Fixed search bars');
