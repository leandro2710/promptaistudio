const fs = require('fs');

const files = ['src/pages/Prompts.tsx', 'src/pages/Packs.tsx', 'src/pages/Favorites.tsx'];

files.forEach(file => {
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace(
    /"px-4 py-2 rounded-2xl text-\[13px\] font-medium whitespace-nowrap transition-all duration-200 border"/g,
    '"px-4 min-h-[44px] rounded-2xl text-[13px] font-medium whitespace-nowrap transition-all duration-200 border flex items-center"'
  );
  fs.writeFileSync(file, code, 'utf8');
});
console.log('Fixed FilterPill');
