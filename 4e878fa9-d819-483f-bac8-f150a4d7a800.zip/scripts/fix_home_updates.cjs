const fs = require('fs');

let code = fs.readFileSync('src/pages/Home.tsx', 'utf8');

code = code.replace(
  /<Bell className="h-5 w-5 text-primary drop-shadow-\[0_0_8px_rgba\(var\(--color-primary\),0\.5\)\] fill-primary\/20" \/>\s*<h2 className="text-xl font-bold tracking-tight">Novidades<\/h2>/g,
  '<Newspaper className="h-5 w-5 text-primary drop-shadow-[0_0_8px_rgba(var(--color-primary),0.5)] fill-primary/20" />\n                 <h2 className="text-lg font-bold tracking-tight">Novidades</h2>'
);

code = code.replace(
  /<div className="flex items-center justify-center shrink-0 px-2">\s*<span className="text-primary text-4xl leading-none">&bull;<\/span>\s*<\/div>/g,
  `<div className="flex items-center justify-center shrink-0 w-14 h-14 rounded-xl bg-primary/10 border border-primary/20">\n                        <Newspaper className="h-6 w-6 text-primary" />\n                      </div>`
);

fs.writeFileSync('src/pages/Home.tsx', code, 'utf8');
console.log('Fixed Home updates section');
