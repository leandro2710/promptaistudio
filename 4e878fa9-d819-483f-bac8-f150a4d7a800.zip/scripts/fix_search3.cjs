const fs = require('fs');

const files = ['src/pages/Prompts.tsx', 'src/pages/Packs.tsx', 'src/pages/Favorites.tsx'];

files.forEach(file => {
  let code = fs.readFileSync(file, 'utf8');
  
  // Find the block:
  // <div className="relative...
  //   <SearchIcon ... />
  //   <input ... />
  // </div>
  // and swap them while setting wrapper to relative z-10
  
  // We can just regex out the pieces but they are multiline.
  if (code.includes('placeholder="Buscar..."')) {
    code = code.replace(
      /<div className="relative w-full mt-4 mb-4">\s*<SearchIcon className="absolute left-4 top-1\/2 -translate-y-1\/2 h-5 w-5 text-zinc-500 pointer-events-none" \/>\s*<input([\s\S]*?)className="(.*?)"\s*\/>\s*<\/div>/g,
      '<div className="relative z-10 w-full mt-4 mb-4">\n        <input$1className="$2"\n        />\n        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-10" />\n      </div>'
    );
  }
  
  if (code.includes('placeholder="Buscar packs..."')) {
    code = code.replace(
      /<div className="relative w-full mt-4 mb-4">\s*<SearchIcon className="absolute left-4 top-1\/2 -translate-y-1\/2 h-5 w-5 text-zinc-500 pointer-events-none" \/>\s*<input([\s\S]*?)className="(.*?)"\s*\/>\s*<\/div>/g,
      '<div className="relative z-10 w-full mt-4 mb-4">\n        <input$1className="$2"\n        />\n        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-10" />\n      </div>'
    );
  }

  if (code.includes('placeholder="Buscar nos favoritos..."')) {
    code = code.replace(
      /<div className="relative w-full mt-4 mb-4">\s*<SearchIcon className="absolute left-4 top-1\/2 -translate-y-1\/2 h-5 w-5 text-zinc-500 pointer-events-none" \/>\s*<input([\s\S]*?)className="(.*?)"\s*\/>\s*<\/div>/g,
      '<div className="relative z-10 w-full mt-4 mb-4">\n            <input$1className="$2"\n            />\n            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-500 pointer-events-none z-10" />\n          </div>'
    );
  }

  fs.writeFileSync(file, code, 'utf8');
});
console.log('Done');
