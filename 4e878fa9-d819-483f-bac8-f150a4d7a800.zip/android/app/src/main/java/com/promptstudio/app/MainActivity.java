package com.promptstudio.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
