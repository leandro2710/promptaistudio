# PromptAI Studio

App público do ecossistema PromptAI Studio.

Uma biblioteca premium de prompts testados para acelerar a criação de conteúdo, integrando diretamente com o banco de dados do \`PromptAI Admin\`.

## ⚙️ Configuração

1. **Mesmo Firebase:** Este app usa **exatamente o mesmo projeto Firebase** do PromptAI Admin.
2. **Configuração Local:** Abra o arquivo \`src/lib/firebase.ts\` (ou configure nas variáveis de ambiente \`.env\`) e cole o mesmo \`firebaseConfig\` que você usou no app Admin.
3. **Autenticação:** Garanta que o Auth pelo Google está ativo.
4. **Firestore:** Confirme que o Firestore está ativo.
5. **Regras de Segurança:** Publique o conteúdo do arquivo \`firestore.rules\` fornecido na raiz deste projeto lá na aba "Rules" do Firestore no console do Firebase.

## 🚀 Como testar

1. Crie categorias, prompts e packs no **PromptAI Admin**.
2. Rode o **PromptAI Studio**.
3. Teste o modo de convidado navegando nos prompts Free ativos. Prompts e Packs Plus possuem cadeado.
4. Faça Login via Google.
5. Torne o seu usuário \`Plus\` lá pelo painel do PromptAI Admin.
6. Volte no app público e veja que o conteúdo Plus foi liberado para sua conta.

## ⚠️ Se os prompts não aparecerem

Possíveis causas:
- O banco Firestore do projeto vinculado está vazio (crie conteúdo no Admin).
- O conteúdo no Admin não foi marcado como "Ativo" (\`active == true\`).
- As regras do Firestore estão bloqueando a visualização pública.
- O \`firebaseConfig\` está incorreto ou ausente.
- A configuração do "Ecosystem ID" no Admin / App Config não confere.
